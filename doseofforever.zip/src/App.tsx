import React, { useState, useEffect, useMemo } from 'react';
import { 
  FlaskConical, 
  Search, 
  Moon, 
  Sun, 
  Heart, 
  ShoppingCart, 
  MessageCircle, 
  Gift, 
  CheckCircle, 
  Truck, 
  FileText, 
  Star, 
  PackageX, 
  Clock, 
  User, 
  MapPin, 
  CreditCard, 
  Plus, 
  Minus, 
  X, 
  Info, 
  ChevronRight, 
  ChevronUp, 
  Award, 
  SlidersHorizontal,
  ThumbsUp,
  Brain,
  Scale,
  Activity,
  Beaker,
  Zap,
  Target,
  LogOut,
  LogIn,
  Copy,
  Check,
  Video,
  Settings,
  LayoutDashboard,
  Receipt,
  Package,
  BarChart3,
  Trash2,
  Edit3,
  Eye,
  RefreshCw,
  ArrowLeft
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { products as initialProductsList } from './data';
import { Product, CartItem, Review } from './types';
import { ProductImage } from './components/ProductImage';
import { CartItemCard } from './components/CartItemCard';
import { BiotechVideoEffect } from './components/BiotechVideoEffect';
import { YoutubeHeroBackground } from './components/YoutubeHeroBackground';
import { GcashQrCode } from './components/GcashQrCode';
import { PeptideCalculator } from './components/PeptideCalculator';
import { ProductAddonsSelector, ADDON_OPTIONS } from './components/ProductAddons';
import { auth, signInWithGoogle, logOut, testConnection, db, handleFirestoreError, OperationType } from './firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { 
  collection, 
  getDocs, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy 
} from 'firebase/firestore';

// Hardcoded reviews generator for added authenticity
const reviewPool = [
  "HPLC purity verified at 99.4%. Reconstituted instantly and cleanly without residue.",
  "Excellent packaging with secure vacuum seals. Prompt shipping to Taguig.",
  "Outstanding research standards. Consistent results across several trial groups.",
  "Highly reliable peptide structure. Vacuum in vial was fully intact upon arrival.",
  "Lalamove delivery arrived within 3 hours. Packed perfectly with insulation."
];

const mockUsers = ["Dr. Santos", "R. Alvarez", "Lab-Tech Manila", "P. Gomez", "Quantum Bio-Lab"];

export default function App() {
  // --- Persistent States & Live Firestore Synchronization ---
  const [productsList, setProductsList] = useState<Product[]>(initialProductsList);
  const [isAdminDashboardOpen, setIsAdminDashboardOpen] = useState(false);
  const [adminActiveTab, setAdminActiveTab] = useState<'dashboard' | 'orders' | 'inventory' | 'sales'>('dashboard');
  const [adminOrders, setAdminOrders] = useState<any[]>([]);
  const [isEditingProduct, setIsEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [viewingReceiptUrl, setViewingReceiptUrl] = useState<string | null>(null);

  // Dynamic Product Form Fields
  const [prodFormName, setProdFormName] = useState('');
  const [prodFormPrice, setProdFormPrice] = useState(0);
  const [prodFormStock, setProdFormStock] = useState(0);
  const [prodFormUnit, setProdFormUnit] = useState('10mg');
  const [prodFormCat, setProdFormCat] = useState('Peptides');
  const [prodFormDesc, setProdFormDesc] = useState('');
  const [prodFormImage, setProdFormImage] = useState('');
  const [prodFormAbbr, setProdFormAbbr] = useState('');

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('peptideph_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [animateCart, setAnimateCart] = useState(false);
  const [prevCartQty, setPrevCartQty] = useState(() => {
    try {
      const saved = localStorage.getItem('peptideph_cart');
      const parsed: CartItem[] = saved ? JSON.parse(saved) : [];
      return parsed.reduce((tot, i) => tot + i.qty, 0);
    } catch {
      return 0;
    }
  });

  useEffect(() => {
    const currentQty = cart.reduce((tot, i) => tot + i.qty, 0);
    if (currentQty > prevCartQty) {
      setAnimateCart(true);
      const timer = setTimeout(() => setAnimateCart(false), 600);
      setPrevCartQty(currentQty);
      return () => clearTimeout(timer);
    } else {
      setPrevCartQty(currentQty);
    }
  }, [cart, prevCartQty]);

  const [wishlist, setWishlist] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('peptideph_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [recentViewed, setRecentViewed] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('peptideph_recent');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem('theme');
      return saved === 'dark' ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  });

  // --- UI Filter States ---
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [priceRange, setPriceRange] = useState<number>(6000);
  const [stockOnly, setStockOnly] = useState(false);
  const [sortBy, setSortBy] = useState<'Popular' | 'LowHigh' | 'HighLow' | 'Alphabetical'>('Popular');
  const [isFilterExpanded, setIsFilterExpanded] = useState(false);

  // --- Modal & Drawer States ---
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [drawerQty, setDrawerQty] = useState(1);
  const [selectedAddonId, setSelectedAddonId] = useState<string>('vial_only');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  
  // --- Quiz States ---
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [quizStep, setQuizStep] = useState(1);
  const [quizSelectedGoal, setQuizSelectedGoal] = useState<string | null>(null);
  const [quizSelectedPurity, setQuizSelectedPurity] = useState<string | null>(null);

  // --- Checkout States ---
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState(1); // 1: Info, 2: Delivery, 3: Payment
  const [coName, setCoName] = useState('');
  const [coMobile, setCoMobile] = useState('');
  const [coEmail, setCoEmail] = useState('');
  const [coDelivery, setCoDelivery] = useState<'lalamove' | 'grab'>('lalamove');
  const [coAddress, setCoAddress] = useState('');
  const [coReceiptFile, setCoReceiptFile] = useState<string>('');
  const [coReceiptPreview, setCoReceiptPreview] = useState<string>('');
  const receiptFileInputRef = React.useRef<HTMLInputElement>(null);
  const [coTerms, setCoTerms] = useState(false);
  const [isSendingMail, setIsSendingMail] = useState(false);
  
  // --- Post-Checkout Order success screen ---
  const [orderSuccessId, setOrderSuccessId] = useState<string | null>(null);
  const [orderSummaryText, setOrderSummaryText] = useState('');

  // --- Toast Notifications State ---
  const [toasts, setToasts] = useState<{ id: string; message: string; type: 'success' | 'warn' | 'info' }[]>([]);

  // --- Live Orders Ticker State ---
  const [liveOrdersCount, setLiveOrdersCount] = useState(47);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // --- Google Sign-In States ---
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  // --- Interactive Laboratory Graphics Background States ---
  const [bgShowGrid, setBgShowGrid] = useState<boolean>(() => {
    const saved = localStorage.getItem('peptideph_bg_grid');
    return saved !== 'false';
  });
  const [bgShowAnatomy, setBgShowAnatomy] = useState<boolean>(() => {
    const saved = localStorage.getItem('peptideph_bg_anatomy');
    return saved !== 'false';
  });
  const [bgShowPortrait, setBgShowPortrait] = useState<boolean>(() => {
    const saved = localStorage.getItem('peptideph_bg_portrait');
    return saved !== 'false';
  });
  const [bgShowMolecules, setBgShowMolecules] = useState<boolean>(() => {
    const saved = localStorage.getItem('peptideph_bg_molecules');
    return saved !== 'false';
  });
  const [bgGlowIntensity, setBgGlowIntensity] = useState<number>(() => {
    const saved = localStorage.getItem('peptideph_bg_glow_intensity');
    return saved ? parseFloat(saved) : 0.65;
  });
  const [bgVideoSpeed, setBgVideoSpeed] = useState<'slow' | 'medium' | 'fast'>(() => {
    return (localStorage.getItem('peptideph_bg_speed') as 'slow' | 'medium' | 'fast') || 'medium';
  });
  const [bgVideoMode, setBgVideoMode] = useState<'cellular' | 'plexus' | 'dna'>(() => {
    return (localStorage.getItem('peptideph_bg_mode') as 'cellular' | 'plexus' | 'dna') || 'plexus';
  });
  const [isEditingVideo, setIsEditingVideo] = useState(false); // Kept the variable name to prevent broken references in standard config panel triggers
  const [heroVideoOpacity, setHeroVideoOpacity] = useState<number>(() => {
    const val = localStorage.getItem('peptideph_hero_video_opacity');
    return val ? parseFloat(val) : 0.6;
  });

  // --- Initialize Secure connection & auth hooks ---
  useEffect(() => {
    testConnection();
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        setCoName(prev => prev || firebaseUser.displayName || '');
        setCoEmail(prev => prev || firebaseUser.email || '');
      }
    });
    return () => unsubscribe();
  }, []);

  // Real-time synchronization of products list from Firestore
  useEffect(() => {
    const q = query(collection(db, 'products'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (snapshot.empty) {
        // Bootstrapping the products database with our robust defaults on initial empty state
        const seedInitialProducts = async () => {
          try {
            for (const p of initialProductsList) {
              await setDoc(doc(db, 'products', String(p.id)), {
                ...p,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
              });
            }
          } catch (err) {
            handleFirestoreError(err, OperationType.WRITE, 'products');
          }
        };
        seedInitialProducts();
      } else {
        const fetched: Product[] = [];
        snapshot.forEach(docSnap => {
          fetched.push(docSnap.data() as Product);
        });
        // Maintain strict chronological/numerical order of product list
        fetched.sort((a, b) => a.id - b.id);
        setProductsList(fetched);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'products');
    });
    return () => unsubscribe();
  }, []);

  // Real-time synchronization of orders (only if current user is the administrator)
  useEffect(() => {
    if (user && user.email === 'pankaj.ydv707@gmail.com') {
      const q = query(collection(db, 'orders'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const list: any[] = [];
        snapshot.forEach(docSnap => {
          list.push(docSnap.data());
        });
        // Sort orders descending by date created
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setAdminOrders(list);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'orders');
      });
      return () => unsubscribe();
    } else {
      // Clear admin list if not administrator
      setAdminOrders([]);
    }
  }, [user]);

  const handleGoogleSignIn = async () => {
    try {
      const loggedUser = await signInWithGoogle();
      if (loggedUser) {
        showToast(`Signed in as ${loggedUser.displayName || 'Researcher'}`, 'success');
      }
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user') {
        showToast(err?.message || 'Google Sign-In failed', 'warn');
      }
    }
  };

  const handleGoogleSignOut = async () => {
    try {
      await logOut();
      showToast('Signed out of researcher session', 'info');
      setIsUserMenuOpen(false);
    } catch (err: any) {
      showToast('Logout failed', 'warn');
    }
  };

  // --- Effects ---
  useEffect(() => {
    localStorage.setItem('peptideph_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('peptideph_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('peptideph_recent', JSON.stringify(recentViewed));
  }, [recentViewed]);

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Handle Scroll to Top visibility
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Live order dynamic simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveOrdersCount(prev => Math.min(99, prev + Math.floor(Math.random() * 2) + 1));
    }, 28000);
    return () => clearInterval(interval);
  }, []);

  // --- Helper Helpers ---
  const showToast = (message: string, type: 'success' | 'warn' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3000);
  };

  const handleToggleWishlist = (productId: number) => {
    const p = productsList.find(x => x.id === productId);
    if (!p) return;
    setWishlist(prev => {
      const isExist = prev.includes(productId);
      if (isExist) {
        showToast(`${p.name} removed from wishlist`, 'info');
        return prev.filter(id => id !== productId);
      } else {
        showToast(`${p.name} added to wishlist`, 'success');
        return [...prev, productId];
      }
    });
  };

  const addToRecent = (productId: number) => {
    setRecentViewed(prev => {
      const filtered = prev.filter(id => id !== productId);
      return [productId, ...filtered].slice(0, 5);
    });
  };

  const handleOpenProduct = (product: Product) => {
    setSelectedProduct(product);
    setDrawerQty(1);
    setSelectedAddonId('vial_only');
    addToRecent(product.id);
  };

  const handleAddToCart = (product: Product, quantity: number, addonId: string = 'vial_only') => {
    if (product.stock === 0) {
      showToast('This item is currently out of stock', 'warn');
      return;
    }

    const addon = ADDON_OPTIONS.find(opt => opt.id === addonId) || ADDON_OPTIONS[0];
    const finalPrice = product.price + addon.priceModifier;

    setCart(prev => {
      const existing = prev.find(item => item.id === product.id && (item.selectedAddonId || 'vial_only') === addonId);
      if (existing) {
        const totalQty = existing.qty + quantity;
        if (totalQty > product.stock) {
          showToast(`Cannot add more. High purity lab limits restricted to remaining ${product.stock} units.`, 'warn');
          return prev;
        }
        showToast(`Updated ${product.name} (${addon.name}) quantity to ${totalQty}`, 'success');
        return prev.map(item => (item.id === product.id && (item.selectedAddonId || 'vial_only') === addonId) ? { ...item, qty: totalQty } : item);
      } else {
        showToast(`Added ${quantity} × ${product.name} (${addon.name}) to research cart`, 'success');
        return [...prev, {
          id: product.id,
          name: product.name,
          unit: product.unit,
          price: finalPrice,
          qty: quantity,
          stock: product.stock,
          image: product.image,
          abbr: product.abbr,
          selectedAddonId: addonId,
          selectedAddonName: addon.name,
          selectedAddonPrice: addon.priceModifier
        }];
      }
    });
  };

  const handleCartQtyChange = (itemId: number, direction: number, addonId: string = 'vial_only') => {
    setCart(prev => {
      return prev.map(item => {
        if (item.id === itemId && (item.selectedAddonId || 'vial_only') === addonId) {
          const newQty = item.qty + direction;
          if (newQty < 1) return item;
          if (newQty > item.stock) {
            showToast(`Laboratory storage limits reached for ${item.name}`, 'warn');
            return item;
          }
          return { ...item, qty: newQty };
        }
        return item;
      });
    });
  };

  const handleRemoveCartItem = (itemId: number, addonId: string = 'vial_only') => {
    const item = cart.find(x => x.id === itemId && (x.selectedAddonId || 'vial_only') === addonId);
    if (item) {
      const addonLabel = item.selectedAddonName ? ` (${item.selectedAddonName})` : '';
      showToast(`Removed ${item.name}${addonLabel} from research cart`, 'info');
    }
    setCart(prev => prev.filter(x => !(x.id === itemId && (x.selectedAddonId || 'vial_only') === addonId)));
  };

  // --- Calculations ---
  const subtotal = useMemo(() => {
    return cart.reduce((tot, item) => tot + (item.price * item.qty), 0);
  }, [cart]);

  const deliveryFee = coDelivery === 'lalamove' ? 150 : 180;
  
  // Unlocks free shipping beyond ₱5,000 PHP
  const isFreeShipping = subtotal >= 5000;
  const finalDeliveryFee = isFreeShipping ? 0 : deliveryFee;
  const totalAmountDue = subtotal + finalDeliveryFee;

  const remainingForFreeShipping = Math.max(0, 5000 - subtotal);
  const freeShippingProgressPercent = Math.min(100, (subtotal / 5000) * 100);

  // --- Filtering Products ---
  const filteredProducts = useMemo(() => {
    let result = [...productsList];

    // Search query match
    if (searchTerm.trim() !== '') {
      const q = searchTerm.toLowerCase();
      result = result.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.abbr.toLowerCase().includes(q) ||
        p.desc.toLowerCase().includes(q)
      );
    }

    // Category match
    if (selectedCategory !== 'All') {
      result = result.filter(p => p.cat === selectedCategory);
    }

    // Cost limit
    result = result.filter(p => p.price <= priceRange);

    // Stock availability
    if (stockOnly) {
      result = result.filter(p => p.stock > 0);
    }

    // Sorting
    if (sortBy === 'Price3350') {
      // Sort logic helper
    }

    if (sortBy === 'LowHigh') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'HighLow') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'Alphabetical') {
      result.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      // Popular (sort by high popularity metric)
      result.sort((a, b) => b.popularity - a.popularity);
    }

    return result;
  }, [searchTerm, selectedCategory, priceRange, stockOnly, sortBy]);

  // Clean filters helper
  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedCategory('All');
    setPriceRange(6000);
    setStockOnly(false);
    setSortBy('Popular');
    showToast('Filters restored to default', 'info');
  };

  // --- Quiz Logic Helper ---
  const handleQuizNext = () => {
    if (quizStep === 1) {
      if (!quizSelectedGoal) {
        showToast('Please select your target research pathway to proceed', 'warn');
        return;
      }
      setQuizStep(2);
    } else if (quizStep === 2) {
      if (!quizSelectedPurity) {
        showToast('Please select structural dose requirement to view recommendations', 'warn');
        return;
      }
      setQuizStep(3);
    }
  };

  // Recommendations based on quiz choices
  const quizRecommendedProducts = useMemo(() => {
    if (!quizSelectedGoal) return [];
    // Category mapping:
    // 'healing_repair' -> 'Peptides'
    // 'metabolism_fatloss' -> 'Weight Loss'
    // 'longevity_longevity' -> 'Cognitive & Sleep'
    // 'lab_standards' -> 'Lab Essentials'
    const categoryMapping: Record<string, string> = {
      'healing': 'Peptides',
      'weight': 'Weight Loss',
      'brain': 'Cognitive & Sleep',
      'standards': 'Lab Essentials'
    };

    const targetCat = categoryMapping[quizSelectedGoal];
    let recs = productsList.filter(p => p.cat === targetCat);
    
    // Slice or adjust based on strength choice
    if (quizSelectedPurity === 'high') {
      recs = recs.filter(p => p.price > 2500);
    } else {
      recs = recs.filter(p => p.price <= 3500);
    }

    return recs.slice(0, 3);
  }, [quizSelectedGoal, quizSelectedPurity]);

  const handleAddQuizProductsToCart = () => {
    if (quizRecommendedProducts.length === 0) return;
    
    quizRecommendedProducts.forEach(product => {
      if (product.stock > 0) {
        setCart(prev => {
          const existing = prev.find(item => item.id === product.id);
          if (existing) {
            return prev.map(item => item.id === product.id ? { ...item, qty: Math.min(product.stock, item.qty + 1) } : item);
          } else {
            return [...prev, {
              id: product.id,
              name: product.name,
              unit: product.unit,
              price: product.price,
              qty: 1,
              stock: product.stock,
              image: product.image,
              abbr: product.abbr
            }];
          }
        });
      }
    });

    showToast('Added matching quiz assays to your research cart', 'success');
    setIsQuizOpen(false);
    setIsCartOpen(true);
    // reset quiz
    setQuizStep(1);
    setQuizSelectedGoal(null);
    setQuizSelectedPurity(null);
  };

  // --- Checkout Wizard Submissions ---
  const handleCheckoutNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (checkoutStep === 1) {
      if (!coName || !coMobile || !coEmail) {
        showToast('Please complete name, mobile number, and email address', 'warn');
        return;
      }
      if (!coEmail.includes('@') || !coEmail.includes('.')) {
        showToast('Please enter a valid academic/research email address', 'warn');
        return;
      }
      setCheckoutStep(2);
    } else if (checkoutStep === 2) {
      if (!coAddress) {
        showToast('Please specify delivery address in the Philippines', 'warn');
        return;
      }
      setCheckoutStep(3);
    }
  };

  const handlePlaceOrder = () => {
    if (!coTerms) {
      showToast('You must confirm that these materials are solely for laboratory research use', 'warn');
      return;
    }
    if (!coReceiptFile) {
      showToast('Please upload payment transaction details to complete reservation', 'warn');
      return;
    }

    const orderId = `PH-RETA-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    setOrderSuccessId(orderId);

    // Save order data dynamically to Firestore of Firebase
    const placeOrderInFirestore = async () => {
      try {
        await setDoc(doc(db, 'orders', orderId), {
          orderId,
          researcherName: coName,
          researcherMobile: coMobile,
          researcherEmail: coEmail,
          items: cart,
          subtotal,
          deliveryOption: coDelivery,
          deliveryFee: finalDeliveryFee,
          totalAmount: totalAmountDue,
          deliveryAddress: coAddress,
          receiptFileName: coReceiptFile,
          receiptFileDataUrl: coReceiptPreview || '',
          status: 'Pending',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        
        // Deduct stocks in dynamic catalog database
        for (const item of cart) {
          const prodInList = productsList.find(p => p.id === item.id);
          if (prodInList) {
            const newStock = Math.max(0, prodInList.stock - item.qty);
            await updateDoc(doc(db, 'products', String(item.id)), {
              stock: newStock,
              updatedAt: new Date().toISOString()
            });
          }
        }
        console.log("Order logged and stocks deducted successfully in Firestore.");
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `orders/${orderId}`);
      }
    };
    
    // Sync write
    placeOrderInFirestore();

    // Build plain-text order receipt template to send through WhatsApp
    const orderItemsStr = cart.map(item => {
      const addonLabel = item.selectedAddonName ? ` [${item.selectedAddonName}]` : '';
      return `• ${item.name}${addonLabel} (${item.unit}) × ${item.qty} - ₱${(item.price * item.qty).toLocaleString()}`;
    }).join('\n');
    const orderInstructions = `*NEW RESEARCH RESERVATION - DOSE OF FOREVER*\n` +
      `--------------------------------------\n` +
      `*Order ID:* ${orderId}\n` +
      `*Researcher:* ${coName}\n` +
      `*Mobile Phone:* ${coMobile}\n` +
      `*Email Check:* ${coEmail}\n\n` +
      `*Requested Items:*\n${orderItemsStr}\n\n` +
      `*Subtotal:* ₱${subtotal.toLocaleString()}\n` +
      `*Delivery Option:* ${coDelivery.toUpperCase()} (₱${finalDeliveryFee.toLocaleString()})\n` +
      `*TOTAL AMOUNT:* ₱${totalAmountDue.toLocaleString()}\n` +
      `*Delivery Destination:*\n${coAddress}\n\n` +
      `*Payment Proof:* Attached GCash Transaction Reference (${coReceiptFile}).\n` +
      `--------------------------------------\n` +
      `*Regulatory Statement:* Confirmed purely for Laboratory Research & Assays in compliance with local guidelines.`;

    setOrderSummaryText(orderInstructions);

    // Call server-side payment & order transactional email gateway
    setIsSendingMail(true);
    showToast('Transmitting invoice and reservation proof...', 'info');

    fetch('/api/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        orderId,
        researcherName: coName,
        researcherMobile: coMobile,
        researcherEmail: coEmail,
        itemsStr: orderItemsStr,
        subtotal,
        deliveryOption: coDelivery,
        deliveryFee: finalDeliveryFee,
        totalAmount: totalAmountDue,
        deliveryAddress: coAddress,
        receiptFileName: coReceiptFile,
        receiptFileDataUrl: coReceiptPreview
      })
    })
      .then(res => res.json())
      .then(data => {
        setIsSendingMail(false);
        if (data.success) {
          if (data.mocked) {
            showToast(data.message, 'info');
          } else {
            showToast('Secure invoice transmitted to researcher and laboratory queue!', 'success');
          }
          setIsCheckoutOpen(false);
        } else {
          console.error("Mail routing dispatch failed:", data.error);
          showToast(data.error || 'Server processed payment proof but details email failed to route.', 'warn');
          // Gracefully open success modal anyway so checkout isn't blocked completely
          setIsCheckoutOpen(false);
        }
      })
      .catch(err => {
        setIsSendingMail(false);
        console.error("Payment confirmation mail service error:", err);
        showToast('Reservation logged. Email status: Network offline.', 'warn');
        // Gracefully open success modal anyway
        setIsCheckoutOpen(false);
      });
  };

  // Real file upload select logic
  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 8 * 1024 * 1024) {
        showToast('Receipt file size exceeds the 8MB limit.', 'warn');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setCoReceiptFile(file.name);
        setCoReceiptPreview(reader.result as string);
        showToast(`Receipt "${file.name}" uploaded successfully!`, 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerRealFileSelect = () => {
    receiptFileInputRef.current?.click();
  };

  // Generate mock reviews for a product
  const getProductReviews = (product: Product): Review[] => {
    const seed1 = product.id % mockUsers.length;
    const seed2 = (product.id + 1) % reviewPool.length;
    const seed3 = (product.id + 2) % mockUsers.length;
    const seed4 = (product.id + 3) % reviewPool.length;

    return [
      {
        user: mockUsers[seed1],
        rating: 5,
        comment: reviewPool[seed2]
      },
      {
        user: mockUsers[seed3],
        rating: 4,
        comment: reviewPool[seed4]
      }
    ];
  };

  // --- ADMIN WORKSPACE LAYOUT (INTERCEPTOR) ---
  if (isAdminDashboardOpen && user && user.email === 'pankaj.ydv707@gmail.com') {
    // CRUD Event handlers for real-time inventory and order updates
    const handleUpdateOrderStatus = async (orderId: string, currentStatus: string) => {
      try {
        const nextStatus = currentStatus === 'Pending' ? 'Completed' : 'Pending';
        const docRef = doc(db, 'orders', orderId);
        await updateDoc(docRef, { status: nextStatus });
        showToast(`Order ${orderId} status toggled to ${nextStatus}`, 'success');
      } catch (err: any) {
        showToast(`Failed to update order status: ${err.message}`, 'warn');
        handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
      }
    };

    const handleAddProduct = async (e: React.FormEvent) => {
      e.preventDefault();
      const nextId = productsList.length > 0 ? Math.max(...productsList.map(p => p.id)) + 1 : 1;
      try {
        const newProduct: Product = {
          id: nextId,
          name: prodFormName,
          abbr: prodFormAbbr || prodFormName.slice(0, 3).toUpperCase(),
          price: Number(prodFormPrice) || 0,
          stock: Number(prodFormStock) || 0,
          unit: prodFormUnit || '10mg',
          cat: prodFormCat || 'Peptides',
          desc: prodFormDesc || 'No formal research protocol details on record.',
          image: prodFormImage || 'https://images.unsplash.com/photo-1579154204601-01588f351167?q=80&w=600&auto=format&fit=crop',
          popularity: 5
        };
        await setDoc(doc(db, 'products', String(nextId)), newProduct);
        showToast(`Successfully registered new formulation: ${prodFormName}`, 'success');
        setIsAddingProduct(false);
        resetFieldsAndForms();
      } catch (err: any) {
        showToast(`Error registering formulation: ${err.message}`, 'warn');
        handleFirestoreError(err, OperationType.CREATE, `products/${nextId}`);
      }
    };

    const triggerEditProductForm = (product: Product) => {
      setIsEditingProduct(product);
      setProdFormName(product.name);
      setProdFormAbbr(product.abbr);
      setProdFormPrice(product.price);
      setProdFormStock(product.stock);
      setProdFormUnit(product.unit);
      setProdFormCat(product.cat);
      setProdFormDesc(product.desc);
      setProdFormImage(product.image);
    };

    const handleEditProduct = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!isEditingProduct) return;
      try {
        const updatedFields = {
          name: prodFormName,
          abbr: prodFormAbbr,
          price: Number(prodFormPrice) || 0,
          stock: Number(prodFormStock) || 0,
          unit: prodFormUnit,
          cat: prodFormCat,
          desc: prodFormDesc,
          image: prodFormImage
        };
        await updateDoc(doc(db, 'products', String(isEditingProduct.id)), updatedFields);
        showToast(`Successfully saved coordinates for ${prodFormName}`, 'success');
        setIsEditingProduct(null);
        resetFieldsAndForms();
      } catch (err: any) {
        showToast(`Error saving formulation coordinates: ${err.message}`, 'warn');
        handleFirestoreError(err, OperationType.UPDATE, `products/${isEditingProduct.id}`);
      }
    };

    const handleDeleteProduct = async (productId: number) => {
      if (!window.confirm('Are you absolutely certain you want to destroy this bio-reagent coordinate? This is irreversibly destructive.')) return;
      try {
        await deleteDoc(doc(db, 'products', String(productId)));
        showToast(`Formulation #${productId} successfully purged from database.`, 'info');
      } catch (err: any) {
        showToast(`Error purging formulation: ${err.message}`, 'warn');
        handleFirestoreError(err, OperationType.DELETE, `products/${productId}`);
      }
    };

    // Calculate metric cards dynamically in real-time
    const totalOrdersCount = adminOrders.length;
    const pendingOrdersCount = adminOrders.filter(o => o.status === 'Pending').length;
    
    const completedOrders = adminOrders.filter(o => o.status === 'Completed');
    const totalSalesSum = completedOrders.reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);
    const totalProductsStockSum = productsList.reduce((sum, p) => sum + (Number(p.stock) || 0), 0);

    // Calculate Best Sellers
    const productSalesMap: Record<number, number> = {};
    completedOrders.forEach(order => {
      const items = Array.isArray(order.items) ? order.items : [];
      items.forEach((item: any) => {
        if (item && typeof item.id === 'number') {
          productSalesMap[item.id] = (productSalesMap[item.id] || 0) + (Number(item.qty) || 0);
        }
      });
    });

    const bestSellersList = Object.entries(productSalesMap)
      .map(([idStr, qty]) => {
        const prod = productsList.find(p => p.id === Number(idStr));
        return {
          product: prod,
          qtySold: qty
        };
      })
      .filter(item => item.product !== undefined)
      .sort((a, b) => b.qtySold - a.qtySold)
      .slice(0, 3);

    // Dynamic Chart Aggregation (Daily, Weekly, Monthly)
    const getChartData = () => {
      const now = new Date();
      if (adminActiveTab === 'sales' || adminActiveTab === 'dashboard') {
        // Daily Chart (Past 7 Days)
        const days = Array.from({ length: 7 }, (_, i) => {
          const d = new Date();
          d.setDate(now.getDate() - (6 - i));
          return d;
        });

        const dailyPoints = days.map(day => {
          const formattedDate = day.toLocaleDateString([], { month: 'short', day: 'numeric' });
          const daySales = completedOrders
            .filter(o => {
              const oDate = new Date(o.createdAt);
              return oDate.getFullYear() === day.getFullYear() &&
                     oDate.getMonth() === day.getMonth() &&
                     oDate.getDate() === day.getDate();
            })
            .reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);
          return { label: formattedDate, value: daySales };
        });

        // Weekly Chart (Past 4 Weeks)
        const weeklyPoints = Array.from({ length: 4 }, (_, i) => {
          const wStart = new Date();
          wStart.setDate(now.getDate() - (3 - i) * 7);
          const label = `Week ${i + 1}`;
          const weekSales = completedOrders
            .filter(o => {
              const oDate = new Date(o.createdAt);
              const diffTime = now.getTime() - oDate.getTime();
              const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
              return diffDays >= (3 - i) * 7 && diffDays < (4 - i) * 7;
            })
            .reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);
          return { label, value: weekSales };
        });

        // Monthly Chart (Past 6 Months)
        const months = Array.from({ length: 6 }, (_, i) => {
          const d = new Date();
          d.setMonth(now.getMonth() - (5 - i));
          return d;
        });

        const monthlyPoints = months.map(m => {
          const label = m.toLocaleDateString([], { month: 'short' });
          const mSales = completedOrders
            .filter(o => {
              const oDate = new Date(o.createdAt);
              return oDate.getFullYear() === m.getFullYear() && oDate.getMonth() === m.getMonth();
            })
            .reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);
          return { label, value: mSales };
        });

        return { dailyPoints, weeklyPoints, monthlyPoints };
      }
      return { dailyPoints: [], weeklyPoints: [], monthlyPoints: [] };
    };

    const chartsData = getChartData();

    // Reset simple state helper
    const resetFieldsAndForms = () => {
      setProdFormName('');
      setProdFormPrice(0);
      setProdFormStock(0);
      setProdFormUnit('10mg');
      setProdFormCat('Peptides');
      setProdFormDesc('');
      setProdFormImage('');
      setProdFormAbbr('');
    };

    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col md:flex-row">
        
        {/* LIGHTBOX POPUP FOR PAYMENT RECEIPTS */}
        <AnimatePresence>
          {viewingReceiptUrl && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-100 bg-slate-950/90 flex items-center justify-center p-4 backdrop-blur-md"
              onClick={() => setViewingReceiptUrl(null)}
            >
              <div className="max-w-2xl w-full relative flex flex-col items-center" onClick={e => e.stopPropagation()}>
                <button 
                  onClick={() => setViewingReceiptUrl(null)}
                  className="absolute -top-12 right-0 p-2.5 rounded-full bg-slate-800 text-slate-100 hover:bg-slate-700 transition"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="text-center mb-3">
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-mono">Proof of GCash Transfer Screenshot</p>
                </div>
                <img 
                  src={viewingReceiptUrl} 
                  alt="GCash Bank Transaction Receipt" 
                  referrerPolicy="no-referrer"
                  className="max-h-[80vh] w-auto max-w-full rounded-2xl shadow-2xl border border-slate-800/80 object-contain"
                />
                <p className="text-center text-xs text-slate-500 mt-2.5 italic">Click outside the receipt to return to workspace</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* SIDEBAR NAVIGATION WORKSPACE */}
        <aside className="w-full md:w-64 bg-slate-900 border-b md:border-b-0 md:border-r border-slate-800 flex-shrink-0 flex flex-col justify-between">
          <div>
            {/* Logo Row */}
            <div className="p-6 border-b border-slate-800/80 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                <FlaskConical className="w-5 h-5 text-slate-950" />
              </div>
              <div>
                <h2 className="font-display font-extrabold text-base tracking-tight text-white leading-tight">Dose of Forever</h2>
                <span className="text-[10px] text-amber-500 font-mono tracking-widest font-bold">ADMIN PANEL</span>
              </div>
            </div>

            {/* Profile Row */}
            <div className="mx-4 my-5 p-3 rounded-xl bg-slate-950/40 border border-slate-800/60 flex items-center gap-3">
              {user.photoURL ? (
                <img src={user.photoURL} alt="Admin Account" referrerPolicy="no-referrer" className="w-9 h-9 rounded-full border border-amber-500/30 object-cover" />
              ) : (
                <div className="w-9 h-9 rounded-full bg-amber-500/20 text-amber-500 flex items-center justify-center font-mono font-bold text-xs">P</div>
              )}
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-slate-100 truncate">{user.displayName || 'Head Admin'}</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                  <span className="text-[9px] font-mono text-slate-400 tracking-wider">SECURE CONTEXT</span>
                </div>
              </div>
            </div>

            {/* Nav Row Items */}
            <nav className="px-3 space-y-1">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
                { id: 'orders', label: 'Orders Queue', icon: Receipt, badge: pendingOrdersCount > 0 ? pendingOrdersCount : undefined },
                { id: 'inventory', label: 'Inventory Suite', icon: Package },
                { id: 'sales', label: 'Sales Reports', icon: BarChart3 },
              ].map(item => {
                const isActive = adminActiveTab === item.id;
                const IconComp = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setAdminActiveTab(item.id as any);
                      setIsAddingProduct(false);
                      setIsEditingProduct(null);
                    }}
                    className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm transition-all text-left cursor-pointer group ${
                      isActive 
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/10' 
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <IconComp className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-slate-400 group-hover:text-amber-500'}`} />
                      <span>{item.label}</span>
                    </div>
                    {item.badge !== undefined && (
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                        isActive ? 'bg-slate-950 text-amber-500' : 'bg-rose-500 text-white'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Sidebar Footer */}
          <div className="p-4 border-t border-slate-800 bg-slate-950/20 space-y-2">
            <button
              onClick={() => setIsAdminDashboardOpen(false)}
              className="w-full flex items-center gap-2 px-3.5 py-2.5 rounded-lg text-xs font-bold text-slate-300 hover:bg-slate-800 hover:text-white transition cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Storefront</span>
            </button>
            <button
              onClick={handleGoogleSignOut}
              className="w-full flex items-center gap-2 px-3.5 py-2.5 rounded-lg text-xs font-bold text-rose-500 hover:bg-rose-500/10 transition cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Terminate Session</span>
            </button>
          </div>
        </aside>

        {/* MAIN BODY AREA CONTENT */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto max-w-7xl mx-auto w-full space-y-6">
          
          {/* WorkSpace Header bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-800/80 pb-5 gap-4">
            <div>
              <h1 className="text-2xl font-display font-extrabold tracking-tight text-white flex items-center gap-2">
                {adminActiveTab === 'dashboard' && 'Administrative Overview'}
                {adminActiveTab === 'orders' && 'Assays & Orders Dispatch'}
                {adminActiveTab === 'inventory' && 'Inventory Control Center'}
                {adminActiveTab === 'sales' && 'Sales Analytics & Revenue'}
              </h1>
              <p className="text-xs text-slate-400 font-mono mt-1">
                Active Client Database: <span className="text-amber-500 font-bold">Verified Cloud System</span> • Manila Center Queue
              </p>
            </div>
            
            {/* Quick action helper bar */}
            <div className="flex items-center gap-2.5 font-mono text-xs">
              <span className="px-3 py-1 bg-slate-900 border border-slate-800/80 text-emerald-400 rounded-full flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
                Firestore Connection: Healthy
              </span>
            </div>
          </div>

          {/* TAB 1: EXECUTIVE OVERVIEW (DASHBOARD) */}
          {(adminActiveTab === 'dashboard' || adminActiveTab === 'sales') && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Total Orders Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover-lift transition">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium text-xs font-mono uppercase tracking-wider">Total Reservations</span>
                  <div className="p-2.5 rounded-lg bg-teal-500/10 text-teal-400">
                    <Receipt className="w-5 h-5 text-teal-400" />
                  </div>
                </div>
                <div className="mt-3">
                  <h3 className="text-2xl font-bold font-mono tracking-tight text-white">{totalOrdersCount}</h3>
                  <p className="text-xs text-slate-500 font-medium mt-1">All orders received via system checkout</p>
                </div>
              </div>

              {/* Pending Orders Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover-lift transition">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium text-xs font-mono uppercase tracking-wider">Pending Release</span>
                  <div className="p-2.5 rounded-lg bg-yellow-500/10 text-yellow-500">
                    <Clock className="w-5 h-5 text-yellow-500" />
                  </div>
                </div>
                <div className="mt-3">
                  <h3 className="text-2xl font-bold font-mono tracking-tight text-white">{pendingOrdersCount}</h3>
                  <p className="text-xs text-slate-500 font-medium mt-1">Awaiting GCash proof validation</p>
                </div>
              </div>

              {/* Total Sales Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover-lift transition border-amber-500/20">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium text-xs font-mono uppercase tracking-wider">Revenue Realized</span>
                  <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-500">
                    <CreditCard className="w-5 h-5 text-amber-500" />
                  </div>
                </div>
                <div className="mt-3">
                  <h3 className="text-2xl font-bold font-mono tracking-tight text-amber-500">₱{totalSalesSum.toLocaleString()}</h3>
                  <p className="text-xs text-slate-500 font-medium mt-1">Completed / Dispatched assays total</p>
                </div>
              </div>

              {/* Products Stock Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover-lift transition">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium text-xs font-mono uppercase tracking-wider">Aerosols & Reagents Stock</span>
                  <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                    <Beaker className="w-5 h-5 text-emerald-400" />
                  </div>
                </div>
                <div className="mt-3">
                  <h3 className="text-2xl font-bold font-mono tracking-tight text-white">{totalProductsStockSum} vials</h3>
                  <p className="text-xs text-slate-500 font-medium mt-1">Total physical inventory in storage</p>
                </div>
              </div>

            </div>
          )}

          {/* DASHBOARD GRAPHICAL WORKSPACE COLUMN */}
          {(adminActiveTab === 'dashboard' || adminActiveTab === 'sales') && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Dynamic SVG Area Sales Chart */}
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-white">Dynamic Sales Curve</h3>
                    <p className="text-[11px] font-mono text-slate-400">Chronological analysis of finalized billing transactions</p>
                  </div>
                  <div className="px-2.5 py-1 text-[10px] border border-amber-500/30 bg-amber-500/5 text-amber-500 rounded font-mono uppercase tracking-wider">
                    Completed Transactions
                  </div>
                </div>

                {/* SVG Line Graph */}
                <div className="h-56 w-full pt-4 relative flex items-end">
                  {(() => {
                    const points = chartsData.dailyPoints;
                    if (points.length === 0) {
                      return <p className="text-center text-slate-500 font-mono text-xs w-full">Waiting for transaction inputs...</p>;
                    }
                    const maxVal = Math.max(...points.map(p => p.value), 4000) * 1.1;
                    
                    // Coordinates generator
                    const w = 550;
                    const h = 180;
                    const padding = 10;
                    
                    const xStep = (w - padding * 2) / (points.length - 1);
                    const coords = points.map((p, idx) => {
                      const x = padding + idx * xStep;
                      const y = h - padding - (p.value / maxVal) * (h - padding * 2);
                      return { x, y };
                    });

                    // Build SVG path
                    const pathD = coords.reduce((acc, c, idx) => {
                      return idx === 0 ? `M ${c.x} ${c.y}` : `${acc} L ${c.x} ${c.y}`;
                    }, '');

                    const areaD = coords.length > 0
                      ? `${pathD} L ${coords[coords.length - 1].x} ${h - padding} L ${coords[0].x} ${h - padding} Z`
                      : '';

                    return (
                      <div className="w-full h-full flex flex-col justify-between">
                        <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-full overflow-visible">
                          <defs>
                            <linearGradient id="glowGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.25" />
                              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.0" />
                            </linearGradient>
                          </defs>
                          
                          {/* Y lines */}
                          <line x1="0" y1={h/3} x2={w} y2={h/3} stroke="#334155" strokeWidth="0.5" strokeDasharray="4 4" />
                          <line x1="0" y1={(2*h)/3} x2={w} y2={(2*h)/3} stroke="#334155" strokeWidth="0.5" strokeDasharray="4 4" />
                          
                          {/* Grid Area */}
                          {areaD && <path d={areaD} fill="url(#glowGrad)" />}
                          {pathD && <path d={pathD} fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />}
                          
                          {/* Nodes points */}
                          {coords.map((c, idx) => (
                            <circle key={idx} cx={c.x} cy={c.y} r="3.5" fill="#1e293b" stroke="#f59e0b" strokeWidth="1.5" />
                          ))}
                        </svg>

                        {/* Labels row */}
                        <div className="flex justify-between text-[10px] text-slate-500 font-mono border-t border-slate-800 pt-2 px-1">
                          {points.map((p, idx) => (
                            <div key={idx} className="text-center flex flex-col">
                              <span>{p.label}</span>
                              <span className="text-slate-300 font-semibold mt-0.5">₱{(p.value / 1000).toFixed(1)}k</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>

              {/* Best-selling Products list */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Best-Selling Formulations</h3>
                  <p className="text-[11px] font-mono text-slate-400 mb-4">Highest volume assays ordered by researchers</p>
                  
                  <div className="space-y-3.5">
                    {bestSellersList.length === 0 ? (
                      <div className="text-center py-10 text-slate-500 font-mono text-xs">
                        No transactions registered yet.
                      </div>
                    ) : (
                      bestSellersList.map((item, idx) => {
                        const p = item.product;
                        const rankColors = ['bg-amber-500 text-slate-950', 'bg-slate-700 text-slate-200', 'bg-bronze text-slate-100'];
                        return (
                          <div key={p.id} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/40">
                            <div className="flex items-center gap-3">
                              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${rankColors[idx] || 'bg-slate-800'}`}>
                                {idx + 1}
                              </span>
                              <div>
                                <p className="text-xs font-semibold text-slate-100">{p.name}</p>
                                <span className="text-[9px] font-mono text-slate-400 uppercase">{p.abbr} • {p.unit}</span>
                              </div>
                            </div>
                            <div className="text-right font-mono">
                              <p className="text-xs text-amber-500 font-bold">{item.qtySold} vials</p>
                              <span className="text-[9px] text-slate-500">sold</span>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
                <div className="border-t border-slate-800/80 mt-4 pt-3.5 flex justify-between items-center text-[11px] font-mono text-slate-500">
                  <span>Data synchronized instantly</span>
                  <span className="text-emerald-500">Online</span>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: SECURE ORDERS DISPATCH QUEUE */}
          {adminActiveTab === 'orders' && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="p-5 border-b border-slate-800 bg-slate-950/20 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
                    <span>Clinical Purchase Requests</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono mt-0.5">Please audit billing receipts to dispatch compounds swiftly</p>
                </div>
              </div>

              {adminOrders.length === 0 ? (
                <div className="p-20 text-center text-slate-500 font-mono space-y-2">
                  <PackageX className="w-10 h-10 text-slate-700 mx-auto" />
                  <p className="text-sm font-bold">Orders ledger is empty</p>
                  <p className="text-xs">No researcher transactions have been recorded on this server zone.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-950/40 border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px] tracking-wider">
                        <th className="py-3 px-5">Order ID & Date</th>
                        <th className="py-3 px-5">Researcher Information</th>
                        <th className="py-3 px-5">Requested Assays</th>
                        <th className="py-3 px-5">Bank Proof Screenshot</th>
                        <th className="py-3 px-5">Bill Total</th>
                        <th className="py-3 px-5">Status Release</th>
                        <th className="py-3 px-5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 bg-slate-900/45">
                      {adminOrders.map((order: any, idx) => {
                        const isPending = order.status === 'Pending';
                        const items = Array.isArray(order.items) ? order.items : [];
                        return (
                          <tr key={order.orderId || idx} className="hover:bg-slate-800/30 transition">
                            {/* ID */}
                            <td className="py-4.5 px-5 font-mono space-y-1">
                              <p className="text-amber-500 font-bold text-xs">{order.orderId}</p>
                              <span className="text-[9px] text-slate-500 flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-600" />
                                {new Date(order.createdAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                              </span>
                            </td>

                            {/* Researcher Contact */}
                            <td className="py-4.5 px-5 space-y-1">
                              <p className="font-semibold text-slate-200">{order.researcherName}</p>
                              <p className="text-[10px] text-slate-400 font-mono">{order.researcherEmail}</p>
                              <p className="text-[10px] text-slate-400 font-mono">{order.researcherMobile}</p>
                              <div className="text-[10px] text-slate-500 font-mono max-w-[180px] p-1 border border-slate-800 rounded bg-slate-950/50 truncate" title={order.deliveryAddress}>
                                Nav: {order.deliveryAddress}
                              </div>
                            </td>

                            {/* Items */}
                            <td className="py-4.5 px-5 space-y-1 max-w-xs">
                              {items.map((it: any, i: number) => (
                                <div key={i} className="flex justify-between items-center bg-slate-950/30 px-2 py-1 rounded border border-slate-800/40 text-[10px] gap-2 mb-1">
                                  <span className="text-slate-200 truncate pr-1" title={it.name}>{it.name} ({it.unit})</span>
                                  <span className="font-mono text-slate-400 font-bold shrink-0">× {it.qty}</span>
                                </div>
                              ))}
                            </td>

                            {/* Bank Screenshot */}
                            <td className="py-4.5 px-5">
                              {order.receiptFileDataUrl ? (
                                <div className="space-y-1.5 flex flex-col items-start">
                                  <div className="relative group cursor-pointer overflow-hidden rounded-md border border-slate-800 w-16 h-10" onClick={() => setViewingReceiptUrl(order.receiptFileDataUrl)}>
                                    <img src={order.receiptFileDataUrl} alt="Payload thumbnail" className="w-full h-full object-cover group-hover:scale-110 transition" referrerPolicy="no-referrer" />
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-[8px] text-white font-mono font-bold transition">VIEW</div>
                                  </div>
                                  <span className="text-[9px] text-slate-400 font-mono select-none truncate max-w-[80px]" title={order.receiptFileName}>{order.receiptFileName}</span>
                                </div>
                              ) : (
                                <span className="text-slate-500 italic text-[10px]">No Attachment</span>
                              )}
                            </td>

                            {/* Bill Total */}
                            <td className="py-4.5 px-5 font-mono">
                              <p className="text-slate-200 font-bold">₱{(Number(order.totalAmount) || 0).toLocaleString()}</p>
                              <p className="text-[9px] text-slate-500">Deliv: {order.deliveryOption?.toUpperCase()}</p>
                            </td>

                            {/* Status badge */}
                            <td className="py-4.5 px-5">
                              <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono tracking-wider ${
                                isPending 
                                  ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20' 
                                  : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              }`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${isPending ? 'bg-yellow-500' : 'bg-emerald-400'}`}></span>
                                {order.status}
                              </span>
                            </td>

                            {/* Action toggle */}
                            <td className="py-4.5 px-5 text-right">
                              <button
                                onClick={() => handleUpdateOrderStatus(order.orderId, order.status)}
                                className={`px-3 py-1.5 rounded-md font-sans font-bold text-[10px] transition-all cursor-pointer ${
                                  isPending 
                                    ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 font-bold' 
                                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                }`}
                              >
                                {isPending ? 'Mark Completed' : 'Revert to Pending'}
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PHYSICAL INVENTORY MANAGEMENT SUITE */}
          {adminActiveTab === 'inventory' && (
            <div className="space-y-6">
              
              {/* Product Manipulation Actions Row */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4.5 rounded-xl">
                <div>
                  <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">Inventory Commands</h3>
                  <p className="text-[11px] text-slate-500 font-mono">Modifying vials coordinates instantly updates storefront catalogs</p>
                </div>
                {!isAddingProduct && !isEditingProduct ? (
                  <button
                    onClick={() => {
                      resetFieldsAndForms();
                      setIsAddingProduct(true);
                    }}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold font-sans text-xs transition cursor-pointer shadow-md shadow-amber-500/10"
                  >
                    <Plus className="w-4 h-4 text-slate-950" />
                    <span>Deploy New Peptide Formulation</span>
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setIsAddingProduct(false);
                      setIsEditingProduct(null);
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-750 hover:bg-slate-800 text-slate-300 font-semibold font-sans text-xs transition cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back to Inventory Ledger</span>
                  </button>
                )}
              </div>

              {/* FORM DEPLOYMENT FOR ADDING OR EDITING */}
              {(isAddingProduct || isEditingProduct) && (
                <motion.div 
                  initial={{ opacity: 0, y: 15 }} 
                  animate={{ opacity: 1, y: 0 }} 
                  className="bg-slate-900 border border-slate-800 rounded-xl p-5 md:p-6"
                >
                  <h3 className="font-display font-semibold text-sm text-slate-100 flex items-center gap-2 mb-4">
                    <Edit3 className="w-4 h-4 text-amber-500" />
                    <span>{isAddingProduct ? 'Deploy Form: New Bio-Reagent Formulation' : `Edit Coordinates: ${isEditingProduct?.name}`}</span>
                  </h3>

                  <form onSubmit={isAddingProduct ? handleAddProduct : handleEditProduct} className="grid grid-cols-1 md:grid-cols-3 gap-5">
                    
                    {/* Column 1 */}
                    <div className="space-y-4 shadow-xs">
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wide text-slate-400 mb-1.5">Designation Name (Aesthetic)</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. Semaglutide High Potency"
                          value={prodFormName}
                          onChange={e => setProdFormName(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500/50"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wide text-slate-400 mb-1.5">Compound Shorthand Abbreviation (Abbr)</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. SEMAG-10"
                          value={prodFormAbbr}
                          onChange={e => setProdFormAbbr(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wide text-slate-400 mb-1.5">Molecular/Vial Dosage Unit</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. 5mg or 10mg"
                          value={prodFormUnit}
                          onChange={e => setProdFormUnit(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800/80 rounded-lg px-3 py-2.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Column 2 */}
                    <div className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wide text-slate-400 mb-1.5">Analytical Classification Category</label>
                        <select
                          value={prodFormCat}
                          onChange={e => setProdFormCat(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800/80 rounded-lg px-3 py-2.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                        >
                          <option value="Peptides">Peptides</option>
                          <option value="Weight Loss">Weight Loss</option>
                          <option value="Cognitive & Sleep">Cognitive & Sleep</option>
                          <option value="Lab Essentials">Lab Essentials</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wide text-slate-400 mb-1.5">PHP Price Per Voucher Vial (₱)</label>
                        <input 
                          type="number" 
                          required
                          min="1"
                          placeholder="3800"
                          value={prodFormPrice || ''}
                          onChange={e => setProdFormPrice(Number(e.target.value))}
                          className="w-full bg-slate-950 border border-slate-800/80 rounded-lg px-3 py-2.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wide text-slate-400 mb-1.5">In-Stock Vial Counts</label>
                        <input 
                          type="number" 
                          required
                          min="0"
                          placeholder="45"
                          value={prodFormStock !== undefined ? prodFormStock : ''}
                          onChange={e => setProdFormStock(Number(e.target.value))}
                          className="w-full bg-slate-950 border border-slate-800/80 rounded-lg px-3 py-2.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Column 3 */}
                    <div className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wide text-slate-400 mb-1.5">Compound Photo Unsplash URL</label>
                        <input 
                          type="url" 
                          placeholder="https://images.unsplash.com/..."
                          value={prodFormImage}
                          onChange={e => setProdFormImage(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800/80 rounded-lg px-3 py-2.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-mono uppercase tracking-wide text-slate-400 mb-1.5">Scientific Research Narrative</label>
                        <textarea 
                          rows={4}
                          placeholder="Provide detailed physical specifications or reconstitution descriptions..."
                          value={prodFormDesc}
                          onChange={e => setProdFormDesc(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800/80 rounded-lg px-3 py-2.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Trigger Buttons */}
                    <div className="md:col-span-3 border-t border-slate-805 pt-4 flex justify-end gap-3 font-sans">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingProduct(false);
                          setIsEditingProduct(null);
                        }}
                        className="px-4.5 py-2.5 rounded-lg border border-slate-800 hover:bg-slate-950 hover:text-white text-slate-350 text-xs font-bold transition cursor-pointer"
                      >
                        Cancel Changes
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-4 h-4 text-slate-950" />
                        <span>{isAddingProduct ? 'Deploy to Catalog' : 'Save New Coordinates'}</span>
                      </button>
                    </div>

                  </form>
                </motion.div>
              )}

              {/* PRODUCT LEDGER SYSTEM TABLE */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-950/40 border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px] tracking-wider select-none">
                        <th className="py-3 px-5">ID & Name</th>
                        <th className="py-3 px-5">Identifier</th>
                        <th className="py-3 px-5">Category</th>
                        <th className="py-3 px-5">Retail Price (₱)</th>
                        <th className="py-3 px-5">Dosage Size</th>
                        <th className="py-3 px-5">Available Stock</th>
                        <th className="py-3 px-5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 bg-slate-900/40">
                      {productsList.map((prod) => {
                        const isLowRange = prod.stock < 10;
                        return (
                          <tr key={prod.id} className="hover:bg-slate-800/25 transition">
                            {/* Name info */}
                            <td className="py-4 px-5">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded bg-slate-950 border border-slate-800/85 overflow-hidden shrink-0">
                                  <img src={prod.image} alt={prod.name} className="w-full h-full object-cover" />
                                </div>
                                <div>
                                  <p className="font-semibold text-slate-200">{prod.name}</p>
                                  <span className="text-[9px] text-slate-500 font-mono">DB Record ID: {prod.id}</span>
                                </div>
                              </div>
                            </td>

                            {/* Identifier */}
                            <td className="py-4 px-5 font-mono text-slate-300 font-semibold">{prod.abbr}</td>

                            {/* Classification */}
                            <td className="py-4 px-5 text-slate-400">{prod.cat}</td>

                            {/* Pricing */}
                            <td className="py-4 px-5 font-mono text-slate-100 font-bold">₱{prod.price.toLocaleString()}</td>

                            {/* Dosage Size */}
                            <td className="py-4 px-5 text-slate-400 font-mono">{prod.unit}</td>

                            {/* Availability stocks count */}
                            <td className="py-4 px-5">
                              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono tracking-wider ${
                                isLowRange 
                                  ? 'bg-rose-500/10 text-rose-500 border border-rose-500/20' 
                                  : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              }`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${isLowRange ? 'bg-rose-500 animate-ping' : 'bg-emerald-400'}`}></span>
                                {prod.stock} vials {isLowRange && 'Low'}
                              </span>
                            </td>

                            {/* Actions layout column */}
                            <td className="py-4 px-5 text-right space-x-1.5">
                              <button
                                onClick={() => {
                                  setIsAddingProduct(false);
                                  triggerEditProductForm(prod);
                                }}
                                className="p-2 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-750 transition cursor-pointer"
                                title="Edit coordinates price and stock"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(prod.id)}
                                className="p-2 rounded bg-rose-950/30 text-rose-400 hover:text-rose-200 hover:bg-rose-950/60 transition cursor-pointer"
                                title="Delete formulation from database"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-sans">
      
      {/* Toast Notification Container */}
      <div className="fixed bottom-4 left-4 z-100 flex flex-col gap-2 pointer-events-none">
        <AnimatePresence>
          {toasts.map(toast => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, y: -20 }}
              className={`p-4 rounded-xl shadow-lg flex items-center gap-3 border pointer-events-auto backdrop-blur-md min-w-[280px] max-w-sm ${
                toast.type === 'warn'
                  ? 'bg-amber-500/90 text-white border-amber-400'
                  : toast.type === 'info'
                  ? 'bg-slate-950/90 text-slate-100 border-slate-800'
                  : 'bg-teal-900/95 text-teal-50 border-teal-800'
              }`}
            >
              <div className="flex-shrink-0">
                {toast.type === 'warn' ? (
                  <Info className="w-5 h-5 text-white" />
                ) : (
                  <CheckCircle className="w-5 h-5 text-teal-300" />
                )}
              </div>
              <p className="text-sm font-medium flex-1">{toast.message}</p>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Top Banner Ticker */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 text-white text-xs py-2.5 px-4 text-center border-b border-teal-900/40 font-mono tracking-wide flex justify-center items-center gap-6 flex-wrap">
        <span className="flex items-center gap-1.5"><CheckCircle className="w-3.5 h-3.5 text-teal-400 inline" /> COA Lab Certified &gt;99% Purity</span>
        <span className="flex items-center gap-1.5"><Truck className="w-3.5 h-3.5 text-teal-400 inline" /> Manila Region Immediate Express Deliveries</span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse"></span>
          <span className="text-teal-300 font-bold">{liveOrdersCount} researchers</span> validated orders today
        </span>
      </div>

      {/* Main Beautiful Header */}
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-900/85 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="max-w-6xl mx-auto px-4 py-3.5 flex items-center justify-between gap-4">
          
          {/* Logo Brand */}
          <div className="flex items-center gap-3 cursor-pointer select-none" onClick={() => { setSelectedCategory('All'); setSearchTerm(''); }}>
            <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white shadow-xl shadow-teal-600/20">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <div className="font-display font-extrabold text-xl tracking-tight text-teal-600 dark:text-teal-400">
                Dose of Forever
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                LABORATORY REAGENTS
              </div>
            </div>
          </div>

          {/* Desktop Search input */}
          <div className="flex-1 max-w-lg hidden md:block relative">
            <input
              type="text"
              placeholder="Search research peptides (e.g., BPC-157, Retatrutide)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-full border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500 dark:focus:border-teal-400 transition-all outline-none text-sm text-slate-700 dark:text-slate-100"
              id="search-input"
            />
            <Search className="absolute left-3.5 top-2.5 text-slate-400 w-4 h-4" />
          </div>

          {/* Header Actions */}
          <div className="flex items-center gap-1.5 sm:gap-3">
            
            {/* Theme trigger */}
            <button
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-colors"
              title="Toggle theme mode"
              id="theme-toggle"
            >
              {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5 text-amber-400" />}
            </button>

            {/* Wishlist triggers */}
            <button
              onClick={() => setIsWishlistOpen(true)}
              className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-all relative"
              title="My wishlist items"
              id="wishlist-drawer-trigger"
            >
              <Heart className={`w-5 h-5 ${wishlist.length > 0 ? 'text-rose-500 fill-rose-500' : ''}`} />
              {wishlist.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white text-[10px] min-w-[18px] h-[18px] rounded-full flex items-center justify-center font-bold px-1 scale-95">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Scientific WhatsApp Chat */}
            <a
              href="https://wa.me/639310103077"
              target="_blank"
              rel="noreferrer"
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border border-slate-200 dark:border-slate-700 hover:border-teal-500/50 hover:bg-teal-50/50 dark:hover:bg-slate-800 font-medium text-xs text-slate-600 dark:text-slate-300 transition-all cursor-pointer"
              id="whatsapp-chat-header"
            >
              <MessageCircle className="w-4 h-4 text-emerald-500" />
              <span>WhatsApp Inquiry</span>
            </a>

            {/* Cart Trigger */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-all relative flex items-center"
              title="Open Research Cart"
              id="cart-drawer-trigger"
            >
              <motion.div
                animate={animateCart ? {
                  scale: [1, 1.3, 0.85, 1.15, 1],
                  rotate: [0, -15, 15, -10, 10, 0]
                } : { scale: 1, rotate: 0 }}
                transition={{ duration: 0.5, ease: "easeInOut" }}
                className="flex items-center justify-center"
              >
                <ShoppingCart className="w-5 h-5" />
              </motion.div>
              {cart.length > 0 && (
                <motion.span 
                  animate={animateCart ? { scale: [0.95, 1.4, 0.95] } : { scale: 0.95 }}
                  transition={{ duration: 0.5 }}
                  className="absolute -top-1.5 -right-1.5 bg-amber-500 text-white text-[10px] min-w-[18px] h-[18px] rounded-full flex items-center justify-center font-bold px-1"
                >
                  {cart.reduce((tot, i) => tot + i.qty, 0)}
                </motion.span>
              )}
            </button>

            {/* Quick Administrator Access Trigger */}
            {user && user.email === 'pankaj.ydv707@gmail.com' && (
              <button
                onClick={() => setIsAdminDashboardOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-full border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 font-semibold text-xs transition-all cursor-pointer shadow-xs"
                title="Enter Administrator Dashboard"
                id="header-admin-quick-trigger"
              >
                <Settings className="w-3.5 h-3.5 text-amber-500 animate-spin-slow" />
                <span className="hidden sm:inline font-mono">ADMIN PANEL</span>
              </button>
            )}

            {/* Google Sign In Tracker */}
            {!user ? (
              <button
                onClick={handleGoogleSignIn}
                className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-teal-600 hover:bg-teal-700 dark:bg-teal-700 dark:hover:bg-teal-600 font-medium text-xs text-white transition-all cursor-pointer shadow-sm"
                title="Sign in with Google"
                id="google-signin-trigger"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span className="hidden sm:inline font-mono tracking-wider font-semibold">SIGN IN</span>
              </button>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-1.5 p-0.5 pr-2.5 rounded-full border border-slate-200 dark:border-slate-700 hover:border-teal-500/50 bg-slate-50 dark:bg-slate-800 transition-all cursor-pointer"
                  title={`${user.displayName || 'Researcher'} Profile`}
                  id="user-profile-menu-trigger"
                >
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.displayName || "User"}
                      referrerPolicy="no-referrer"
                      className="w-7 h-7 rounded-full object-cover border border-teal-500/30"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-teal-600 text-white flex items-center justify-center font-mono font-bold text-xs uppercase">
                      {(user.displayName || user.email || 'U').charAt(0)}
                    </div>
                  )}
                  <span className="hidden md:inline text-xs font-mono font-medium max-w-[80px] truncate text-slate-700 dark:text-slate-300">
                    {(user.displayName || 'Researcher').split(' ')[0]}
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse hidden sm:inline" />
                </button>

                {/* Account Dropdown Menu */}
                <AnimatePresence>
                  {isUserMenuOpen && (
                    <>
                      <div 
                        className="fixed inset-0 z-40" 
                        onClick={() => setIsUserMenuOpen(false)} 
                        id="user-menu-backdrop-overlay"
                      />
                      
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-4 shadow-xl z-50 text-slate-800 dark:text-slate-150"
                        id="user-profile-menu-dropdown"
                      >
                        <div className="flex items-start gap-3 border-b border-slate-150/10 dark:border-slate-700/50 pb-3 mb-3">
                          {user.photoURL ? (
                            <img
                              src={user.photoURL}
                              alt={user.displayName || "User"}
                              referrerPolicy="no-referrer"
                              className="w-10 h-10 rounded-full object-cover"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-full bg-teal-600 text-white flex items-center justify-center font-mono font-bold text-base uppercase">
                              {(user.displayName || user.email || 'U').charAt(0)}
                            </div>
                          )}
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold truncate leading-tight text-slate-900 dark:text-white">
                              {user.displayName || 'Authorized Researcher'}
                            </p>
                            <p className="text-[11px] text-slate-400 truncate mt-0.5 tracking-tight">
                              {user.email}
                            </p>
                            <span className="inline-flex mt-1 items-center px-1.5 py-0.5 rounded text-[9px] font-mono font-medium bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/15">
                              Purity Tier 1
                            </span>
                          </div>
                        </div>

                        <div className="mb-3.5 space-y-1">
                          <span className="text-[9px] font-mono font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">
                            Researcher UID
                          </span>
                          <div className="flex items-center justify-between gap-1.5 p-1.5 px-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800">
                            <span className="font-mono text-[10px] text-slate-600 dark:text-slate-300 font-medium select-all truncate max-w-[170px]" id="user-uid-display">
                              {user.uid}
                            </span>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(user.uid);
                                showToast('Researcher ID copied', 'success');
                              }}
                              className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-md text-slate-400 hover:text-teal-500 dark:hover:text-teal-400 transition-colors cursor-pointer"
                              title="Copy UID to clipboard"
                              id="user-uid-copy-btn"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div className="space-y-1 text-xs">
                          <div className="p-2 border border-dashed border-teal-500/20 rounded-xl bg-teal-500/5 mb-3 text-[10px] text-teal-600 dark:text-teal-400 flex items-center gap-1.5">
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                            </span>
                            Session secure and verified.
                          </div>

                          {user.email === 'pankaj.ydv707@gmail.com' && (
                            <button
                              onClick={() => {
                                setIsAdminDashboardOpen(true);
                                setIsUserMenuOpen(false);
                              }}
                              className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-amber-500 hover:bg-amber-500/10 hover:text-amber-600 text-left transition-colors font-semibold cursor-pointer mb-2 border border-amber-500/20 bg-amber-500/5"
                              id="user-profile-admin-dashboard-btn"
                            >
                              <LayoutDashboard className="w-4 h-4 text-amber-500" />
                              <span>Admin Dashboard</span>
                            </button>
                          )}

                          <button
                            onClick={handleGoogleSignOut}
                            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-rose-500 hover:bg-rose-500/10 hover:text-rose-600 text-left transition-colors font-medium cursor-pointer"
                            id="user-profile-logout-btn"
                          >
                            <LogOut className="w-4 h-4" />
                            <span>Close Session</span>
                          </button>
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            )}

          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="md:hidden px-4 pb-3.5">
          <div className="relative">
            <input
              type="text"
              placeholder="Search high-purity peptides..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-full border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500 transition-all outline-none text-sm text-slate-700 dark:text-slate-100"
              id="mobile-search-input"
            />
            <Search className="absolute left-3.5 top-3 text-slate-400 w-4 h-4" />
          </div>
        </div>
      </header>

      {/* Post-Order WhatsApp Dispatch Card (Success Screen Modal) */}
      {orderSuccessId && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4">
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white dark:bg-slate-800 rounded-3xl p-6 md:p-8 max-w-2xl w-full text-center shadow-2xl relative border border-slate-100 dark:border-slate-700"
          >
            <div className="w-16 h-16 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-10 h-10" />
            </div>
            
            <h2 className="text-3xl font-display font-extrabold text-teal-600 dark:text-teal-400 mb-2">
              Research Order Placed!
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm mb-6 max-w-lg mx-auto">
              Your high-purity reagents reservation with ID <span className="font-mono font-bold text-slate-800 dark:text-white bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded text-xs">{orderSuccessId}</span> has been processed. 
              Please click below to instantly dispatch your receipt to our lab logistics team via WhatsApp for same-day Manila delivery.
            </p>

            <div className="bg-slate-100 dark:bg-slate-900/50 rounded-2xl p-4 text-left font-mono text-xs text-slate-600 dark:text-slate-300 max-h-48 overflow-y-auto mb-6 border border-slate-200/50 dark:border-slate-800">
              <pre className="whitespace-pre-wrap">{orderSummaryText}</pre>
            </div>

            <div className="grid sm:grid-cols-2 gap-3 max-w-lg mx-auto">
              {/* Dispatch Action */}
              <a
                href={`https://wa.me/639310103077?text=${encodeURIComponent(orderSummaryText)}`}
                target="_blank"
                rel="noreferrer"
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3.5 px-6 rounded-full inline-flex items-center justify-center gap-2 transition shadow-xl shadow-emerald-500/20 text-sm"
                onClick={() => {
                  setCart([]);
                  setOrderSuccessId(null);
                }}
                id="whatsapp-dispatch-btn"
              >
                <MessageCircle className="w-5 h-5 fill-white" />
                <span>Dispatch via WhatsApp</span>
              </a>

              {/* Close to reset */}
              <button
                onClick={() => {
                  setCart([]);
                  setOrderSuccessId(null);
                }}
                className="w-full bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-white font-bold py-3.5 px-6 rounded-full transition text-sm"
                id="dismiss-success-btn"
              >
                Return to Lab Store
              </button>
            </div>
            
            <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-4 italic">
              *Our courier partners (Lalamove & Grab) will require receipt validation prior to dispatch.
            </p>
          </motion.div>
        </div>
      )}

      {/* Hero Showcase Section */}
      <section className="max-w-6xl mx-auto px-4 mt-6">
        <div className="relative overflow-hidden rounded-3xl bg-slate-950 border border-teal-950 shadow-2xl">
          {/* --- STUNNING CLINICAL GRAPHICS POSTER BACKGROUND --- */}
          {/* Main Dark Science Canvas with custom ambient graticule and color gradient */}
          <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-teal-950/80 to-slate-900/60 pointer-events-none z-0" />

          {/* ACTIVE DYNAMIC MOLECULAR SYNTHESIS INTERACTIVE VIDEO BACKGROUND EFFECT */}
          <YoutubeHeroBackground 
            videoId="PC_havKf-ZA"
            opacity={bgGlowIntensity * 0.45}
          />

          <BiotechVideoEffect 
            glowIntensity={bgGlowIntensity * 0.4}
            showGrid={bgShowGrid}
            showMolecules={bgShowMolecules}
            speed={bgVideoSpeed}
            mode={bgVideoMode}
          />

          {/* Hexagonal Grid Blueprint Overlay (Toggleable) */}
          {bgShowGrid && (
            <div 
              className="absolute inset-0 opacity-20 pointer-events-none z-0 mix-blend-overlay bg-repeat"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='49' viewBox='0 0 28 49'%3E%3Cpath fill='none' stroke='%2306b6d4' stroke-width='0.5' d='M14 0 L28 8 L28 24 L14 32 L0 24 L0 8 Z M0 33 L14 41 L28 33 L28 49 L14 49 L0 49 Z'/%3E%3C/svg%3E")`,
                backgroundSize: '40px'
              }}
            />
          )}

          {/* Cosmic Glow Flare Blobs driving high-tech biological ambiance */}
          <div 
            className="absolute -top-1/4 left-1/4 w-96 h-96 bg-cyan-500/25 rounded-full blur-3xl pointer-events-none z-0" 
            style={{ opacity: bgGlowIntensity }}
          />
          <div 
            className="absolute -bottom-1/4 right-1/4 w-96 h-96 bg-amber-500/15 rounded-full blur-3xl pointer-events-none z-0" 
            style={{ opacity: bgGlowIntensity }}
          />

          {/* Left Side: Translucent Blue Holographic Digital Human Silhouette (Toggleable) */}
          {bgShowAnatomy && (
            <div className="absolute top-1/2 -left-10 lg:left-6 -translate-y-1/2 w-[220px] sm:w-[320px] h-full opacity-35 lg:opacity-40 pointer-events-none z-0 mix-blend-screen select-none">
              <svg className="w-full h-full text-cyan-400" viewBox="0 0 300 500" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Abstract humanoid glowing wireframe */}
                <g stroke="currentColor" strokeWidth="0.75">
                  {/* Outer aura circles */}
                  <circle cx="150" cy="80" r="18" strokeDasharray="3,3" opacity="0.5" />
                  <circle cx="150" cy="180" r="85" strokeDasharray="4,4" opacity="0.3" />
                  
                  {/* Cranium and brain active core */}
                  <ellipse cx="150" cy="80" rx="14" ry="18" />
                  <circle cx="150" cy="80" r="4" fill="cyan" className="animate-pulse" />
                  
                  {/* Spinal column conduit */}
                  <line x1="150" y1="98" x2="150" y2="300" strokeWidth="1.5" />
                  
                  {/* Thorax wireframe cage */}
                  <path d="M 125 125 C 125 110, 175 110, 175 125 L 170 210 C 170 220, 130 220, 130 210 Z" />
                  <line x1="130" y1="140" x2="170" y2="140" />
                  <line x1="128" y1="160" x2="172" y2="160" />
                  <line x1="130" y1="180" x2="170" y2="180" opacity="0.8" />
                  <line x1="135" y1="200" x2="165" y2="200" opacity="0.6" />
                  
                  {/* Pelvic girdle */}
                  <path d="M 130 240 L 170 240 L 160 270 L 140 270 Z" />

                  {/* Arm structures (Symmetrical outward stance) */}
                  <path d="M 125 125 L 94 185 L 75 240" />
                  <path d="M 175 125 L 206 185 L 225 240" />
                  
                  {/* Leg structures */}
                  <path d="M 140 270 L 130 370 L 115 480" />
                  <path d="M 160 270 L 170 370 L 185 480" />
                  
                  {/* Interactive clinical nodes representing cellular energy receptors */}
                  <circle cx="150" cy="130" r="3" fill="#22d3ee" />
                  <circle cx="132" cy="155" r="2.5" fill="#22d3ee" />
                  <circle cx="168" cy="155" r="2.5" fill="#22d3ee" />
                  <circle cx="150" cy="170" r="3" fill="#22d3ee" />
                  <circle cx="150" cy="220" r="3" fill="#f59e0b" className="animate-pulse" />
                  <circle cx="94" cy="185" r="2" fill="#22d3ee" />
                  <circle cx="206" cy="185" r="2" fill="#22d3ee" />
                  <circle cx="130" cy="370" r="2.5" fill="#22d3ee" />
                  <circle cx="170" cy="370" r="2.5" fill="#22d3ee" />
                </g>
                
                {/* Floating DNA double-helix on left background margin */}
                <g stroke="#0891b2" strokeWidth="0.5" opacity="0.4">
                  <path d="M 60 100 Q 85 130, 60 160 T 60 220 T 60 280 T 60 340" fill="none" />
                  <path d="M 85 100 Q 60 130, 85 160 T 85 220 T 85 280 T 85 340" fill="none" />
                  <line x1="62" y1="115" x2="83" y2="115" />
                  <line x1="72" y1="130" x2="73" y2="130" />
                  <line x1="62" y1="145" x2="83" y2="145" />
                  <line x1="61" y1="175" x2="84" y2="175" />
                  <line x1="72" y1="190" x2="73" y2="190" />
                  <line x1="61" y1="205" x2="84" y2="205" />
                  <line x1="62" y1="235" x2="83" y2="235" />
                  <line x1="72" y1="250" x2="73" y2="250" />
                  <line x1="62" y1="265" x2="83" y2="265" />
                </g>
              </svg>
            </div>
          )}

          {/* Right Side: Glowing Portrait Silhouette of a Beautiful Woman (Toggleable) */}
          {bgShowPortrait && (
            <div className="absolute top-1/2 -right-4 lg:right-6 -translate-y-1/2 w-[220px] sm:w-[325px] h-full opacity-30 lg:opacity-35 pointer-events-none z-0 mix-blend-screen select-none">
              <svg className="w-full h-full text-amber-300" viewBox="0 0 300 500" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Outlined profile vector representing rejuvenating beauty */}
                <path 
                  d="M 280 80 C 230 75, 170 105, 160 145 C 158 155, 150 178, 140 185 C 135 188, 128 184, 125 195 C 122 205, 132 215, 134 225 C 136 235, 130 242, 126 248 C 122 254, 118 260, 121 267 C 125 275, 140 280, 145 285 C 155 295, 158 315, 165 328 C 172 340, 195 385, 235 410 C 265 425, 290 430, 290 430" 
                  stroke="currentColor" 
                  strokeWidth="1" 
                  strokeLinecap="round" 
                  strokeDasharray="500" 
                  strokeDashoffset="0"
                />
                {/* Glowing skin aura details */}
                <path 
                  d="M 160 145 Q 185 160, 205 152 Q 225 144, 250 160" 
                  stroke="currentColor" 
                  strokeWidth="0.5" 
                  opacity="0.3" 
                />
                <path 
                  d="M 145 285 Q 175 282, 195 300 Q 215 318, 230 310" 
                  stroke="currentColor" 
                  strokeWidth="0.5" 
                  opacity="0.3" 
                />
                <circle cx="165" cy="185" r="1.5" fill="#f59e0b" />
                <circle cx="185" cy="205" r="1" fill="#f59e0b" />
                <circle cx="160" cy="245" r="1.5" fill="#f59e0b" />
                
                {/* Golden active gene strands floating behind face profile */}
                <g stroke="#d97706" strokeWidth="0.5" opacity="0.35">
                  <path d="M 230 150 Q 200 190, 230 230 T 230 310" fill="none" />
                  <path d="M 205 150 Q 235 190, 205 230 T 205 310" fill="none" />
                  <line x1="208" y1="170" x2="227" y2="170" />
                  <line x1="208" y1="210" x2="227" y2="210" />
                  <line x1="208" y1="250" x2="227" y2="250" />
                  <line x1="208" y1="290" x2="227" y2="290" />
                </g>
              </svg>
            </div>
          )}

          {/* Glowing Molecular Connections Linking Human Cells to Active Ingredients (Toggleable) */}
          {bgShowMolecules && (
            <div className="absolute inset-0 pointer-events-none z-[1]">
              <svg className="w-full h-full" viewBox="0 0 1000 500" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="link-cyan-gold" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.4" />
                    <stop offset="50%" stopColor="#0d9488" stopOpacity="0.6" />
                    <stop offset="100%" stopColor="#fbbf24" stopOpacity="0.4" />
                  </linearGradient>
                </defs>
                {/* Glowing molecular pathways snaking across pedestals */}
                <g stroke="url(#link-cyan-gold)" strokeWidth="1" fill="none">
                  <path d="M 180 200 Q 300 130, 420 185 T 660 170 T 820 220" className="opacity-40" />
                  <path d="M 180 200 Q 240 280, 520 240 T 820 220" className="opacity-30" />
                  
                  {/* Molecular hubs with labels floating above pedestals */}
                  <g className="opacity-75 font-mono text-[9px] fill-cyan-400">
                    <line x1="420" y1="185" x2="420" y2="140" stroke="#06b6d4" strokeWidth="0.5" strokeDasharray="2,2" />
                    <circle cx="420" cy="140" r="3" fill="#22d3ee" />
                    <text x="428" y="143" letterSpacing="1">CJC-1295</text>

                    <line x1="530" y1="190" x2="530" y2="130" stroke="#0d9488" strokeWidth="0.5" strokeDasharray="2,2" />
                    <circle cx="530" cy="130" r="3" fill="#0d9488" />
                    <text x="538" y="133" letterSpacing="1">BPC-157</text>

                    <line x1="680" y1="175" x2="680" y2="115" stroke="#fbbf24" strokeWidth="0.5" strokeDasharray="2,2" />
                    <circle cx="680" cy="115" r="3" fill="#fbbf24" className="animate-pulse" />
                    <text x="688" y="118" fill="#fbbf24" letterSpacing="1">GHK-Cu</text>
                  </g>
                </g>
              </svg>
            </div>
          )}
          
          <div className="relative p-8 md:p-12 z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-1.5 bg-teal-500/15 border border-teal-500/30 text-teal-300 font-mono text-[11px] px-3 py-1 rounded-full mb-4">
                <Award className="w-3.5 h-3.5" /> Direct Reagent Distributing Center Philippines
              </div>
              
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-display font-extrabold text-white leading-tight">
                Premium Research <span className="text-amber-400">Peptides</span> for Clinical Assays
              </h1>
              
              <p className="mt-4 text-teal-100/85 text-sm sm:text-base leading-relaxed max-w-xl">
                Lyophilized state research standards with HPLC analysis records. Fast shipping to key metros: Quezon, Makati, Manila, and Cebu. Guaranteed same-day local dispatch.
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <button
                  onClick={() => {
                    setQuizStep(1);
                    setQuizSelectedGoal(null);
                    setQuizSelectedPurity(null);
                    setIsQuizOpen(true);
                  }}
                  className="bg-amber-500 hover:bg-amber-600 text-slate-900 px-6 py-3 rounded-full font-bold text-sm flex items-center gap-2 shadow-lg hover:shadow-xl transition-all cursor-pointer"
                  id="start-quiz-hero-btn"
                >
                  <FlaskConical className="w-4 h-4" /> Recommended Assay Quiz
                </button>
                <a
                  href="https://wa.me/639310103077"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-full font-semibold text-sm flex items-center gap-2 border border-white/20 hover:border-white/40 transition-all"
                  id="whatsapp-chat-hero-btn"
                >
                  <MessageCircle className="w-4 h-4" /> Direct Lab Chat
                </a>
              </div>
            </div>

            {/* Fast Summary Stats Box */}
            <div className="bg-slate-900/65 backdrop-blur-md p-6 rounded-2xl border border-teal-500/20 max-w-sm w-full font-mono text-xs text-teal-200 space-y-3.5">
              <div className="text-white font-bold tracking-wider uppercase border-b border-teal-900/30 pb-2 flex justify-between items-center bg-teal-950/20 px-1">
                <span>PH ASSAY COMPLIANCE</span>
                <span className="text-[10px] text-amber-500">LIVE READY</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Purity Threshold:</span>
                <span className="text-teal-300 font-bold">&gt;99% HPLC/LC-MS</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Vials Catalog:</span>
                <span className="text-teal-300 font-bold">43 Assays In Stock</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Thermal Packing:</span>
                <span className="text-teal-300 font-bold">Refrigerated Kits</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Target Purpose:</span>
                <span className="text-amber-500 font-bold">In-Vitro Research Only</span>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Free Shipping Banner Display */}
      <section className="max-w-6xl mx-auto px-4 mt-6">
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm transition-all flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-amber-500/10 text-amber-500 rounded-xl flex items-center justify-center">
              <Gift className="w-5.5 h-5.5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <span>Free Insured Transport in Metro Manila</span>
                <span className="bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 text-[10px] px-2.5 py-0.5 rounded-full font-mono">
                  PROMO UNLOCKED at ₱5,000
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Maintain standard temperature protocol via refrigerated container delivery to preserve organic peptide structure.
              </p>
            </div>
          </div>

          <div className="md:w-72 shrink-0">
            <div className="flex justify-between text-xs font-mono mb-1.5">
              <span className="text-slate-500 dark:text-slate-400 font-semibold">
                {isFreeShipping ? '🎉 Free delivery unlocked!' : `Add ₱${remainingForFreeShipping.toLocaleString()} more`}
              </span>
              <span className="text-teal-600 dark:text-teal-400 font-bold">
                ₱{subtotal.toLocaleString()} / ₱5,000
              </span>
            </div>
            
            <div className="h-3 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden p-0.5 border border-slate-200/40 dark:border-slate-800/80">
              <div 
                className="h-full rounded-full bg-gradient-to-r from-teal-500 to-amber-400 transition-all duration-500" 
                style={{ width: `${freeShippingProgressPercent}%` }}
              ></div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Filter & Products Display Grid */}
      <section className="max-w-6xl mx-auto px-4 mt-8 pb-16">
        
        {/* Category Header Controls */}
        <div className="flex flex-col gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          
          <div className="flex flex-wrap items-center justify-between gap-4">
            
            {/* Category selection scroll list */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
              {[
                { name: 'All', icon: '🧬', count: productsList.length },
                { name: 'Peptides', icon: '🧬', count: productsList.filter(x => x.cat === 'Peptides').length },
                { name: 'Weight Loss', icon: '⚖️', count: productsList.filter(x => x.cat === 'Weight Loss').length },
                { name: 'Cognitive & Sleep', icon: '🧠', count: productsList.filter(x => x.cat === 'Cognitive & Sleep').length },
                { name: 'Lab Essentials', icon: '🧪', count: productsList.filter(x => x.cat === 'Lab Essentials').length },
                { name: 'Peptide Dosage Calculator', icon: '🧮', isSpecial: true }
              ].map(catItem => {
                const isActive = selectedCategory === catItem.name;
                return (
                  <button
                    key={catItem.name}
                    onClick={() => { setSelectedCategory(catItem.name); }}
                    className={`px-4.5 py-2 rounded-full text-nowrap text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                      isActive 
                        ? 'bg-teal-600 text-white shadow-md shadow-teal-600/10'
                        : 'bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <span>{catItem.icon}</span>
                    <span>{catItem.name}</span>
                    {catItem.count !== undefined && (
                      <span className={`text-[10px] font-mono rounded-full px-1.5 py-0.2 ${isActive ? 'bg-teal-700/80 text-teal-100' : 'bg-slate-100 dark:bg-slate-700 text-slate-400'}`}>
                        {catItem.count}
                      </span>
                    )}
                    {catItem.isSpecial && (
                      <span className="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.2 rounded-full bg-teal-500/20 text-teal-400">
                        Calc
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Advanced Filters Expand/Collapse Toggle */}
            {selectedCategory !== 'Peptide Dosage Calculator' && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsFilterExpanded(!isFilterExpanded)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold cursor-pointer border transition-colors ${
                    isFilterExpanded || priceRange < 6000 || stockOnly
                      ? 'bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400 border-teal-300 dark:border-teal-800'
                      : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                  id="advanced-filters-btn"
                >
                  <SlidersHorizontal className="w-4 h-4" />
                  <span>Filters</span>
                  {(priceRange < 6000 || stockOnly) && (
                    <span className="w-2 h-2 rounded-full bg-teal-500 animate-pulse"></span>
                  )}
                </button>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 rounded-full px-4 py-2 text-xs font-semibold outline-none focus:ring-1 focus:ring-teal-500"
                  title="Sort Products Grid"
                  id="sort-select"
                >
                  <option value="Popular">⭐ Popularity Ranking</option>
                  <option value="LowHigh">💸 Cost: Low to High</option>
                  <option value="HighLow">💰 Cost: High to Low</option>
                  <option value="Alphabetical">🔤 Name: Alphabetical</option>
                </select>
              </div>
            )}

          </div>

          {/* Interactive filter dropdown panels */}
          <AnimatePresence>
            {isFilterExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="bg-white dark:bg-slate-800/50 rounded-2xl p-5 mt-2 border border-slate-200/60 dark:border-slate-800 grid sm:grid-cols-2 md:grid-cols-3 gap-6">
                  
                  {/* Slider Control */}
                  <div>
                    <label className="block text-xs font-mono text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-2 font-bold flex justify-between">
                      <span>Maximum Budget:</span>
                      <span className="text-teal-600 dark:text-teal-400 font-bold font-sans">₱{priceRange.toLocaleString()} PHP</span>
                    </label>
                    <input
                      type="range"
                      min="180"
                      max="6000"
                      step="100"
                      value={priceRange}
                      onChange={(e) => setPriceRange(parseInt(e.target.value))}
                      className="w-full accent-teal-600 cursor-pointer h-2 bg-slate-100 dark:bg-slate-700 rounded-full"
                    />
                    <div className="flex justify-between text-[11px] text-slate-400 font-mono mt-1">
                      <span>₱180</span>
                      <span>₱3,000</span>
                      <span>₱6,000+</span>
                    </div>
                  </div>

                  {/* Stock Availability Toggle */}
                  <div className="flex flex-col justify-center">
                    <span className="block text-xs font-mono text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-2.5 font-bold">
                      AVAILABILITY RESTRICTIONS
                    </span>
                    <label className="inline-flex items-center gap-2.5 select-none text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-semibold cursor-pointer">
                      <input
                        type="checkbox"
                        checked={stockOnly}
                        onChange={(e) => setStockOnly(e.target.checked)}
                        className="rounded border-slate-300 dark:border-slate-700 text-teal-600 w-4 h-4 focus:ring-teal-500"
                      />
                      <span>In-Stock Analytical Assays Only</span>
                    </label>
                  </div>

                  {/* Quick Filters Info */}
                  <div className="sm:col-span-2 md:col-span-1 flex flex-col justify-between p-3.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700/60">
                    <div className="flex gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <Info className="w-4 h-4 text-teal-500 flex-shrink-0" />
                      <p>
                        Our laboratory standards are batch checked through LC-MS authentication to guarantee purity thresholds.
                      </p>
                    </div>
                    
                    <button
                      onClick={handleResetFilters}
                      className="text-left text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline mt-2 self-start"
                      id="reset-filters-btn"
                    >
                      Clear All Filter Configurations →
                    </button>
                  </div>

                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </div>

        {selectedCategory === 'Peptide Dosage Calculator' ? (
          <div className="mt-8 transition-all duration-300">
            <PeptideCalculator />
          </div>
        ) : (
          <>
            {/* Dynamic Items Counter Info */}
            <div className="mt-4 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1 font-mono">
              <span>
                DISCOVERING <strong className="text-slate-700 dark:text-slate-300">{filteredProducts.length}</strong> SCIENTIFIC VIALS / REAGENTS
              </span>
              {searchTerm && (
                <span>
                  SEARCH PHRASE: &quot;{searchTerm}&quot;
                </span>
              )}
            </div>

            {/* Product Bento Grid */}
            {filteredProducts.length === 0 ? (
              <div className="auth-error-state text-center py-20 bg-white dark:bg-slate-800/20 border border-dashed border-slate-300 dark:border-slate-800 rounded-2xl mt-6 px-4">
                <PackageX className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                <h3 className="font-bold text-lg text-slate-700 dark:text-white">Assay Standard Not Found</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1">
                  No chemical formulas matched your distinct search filters. Please adjust pricing budget or test other categorizations.
                </p>
                <button
                  onClick={handleResetFilters}
                  className="mt-4 px-6 py-2 bg-teal-600 text-white rounded-full font-bold text-xs shadow-lg hover:bg-teal-700 transition"
                  id="empty-reset-filters-btn"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-6">
                {filteredProducts.map(product => {
                  const outOfStock = product.stock === 0;
                  const isInWishlist = wishlist.includes(product.id);
                  
                  return (
                    <div
                      key={product.id}
                      onClick={() => handleOpenProduct(product)}
                      className="bg-white dark:bg-slate-800/90 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 hover-lift shadow-sm hover:shadow-xl transition-all cursor-pointer relative flex flex-col group"
                      id={`product-card-${product.id}`}
                    >
                      
                      {/* Item Image Top */}
                      <div className="aspect-square bg-slate-100 dark:bg-slate-900 w-full relative overflow-hidden flex-shrink-0">
                        
                        {outOfStock && (
                          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-[1px] flex flex-col items-center justify-center text-white text-xs font-bold font-mono z-10 tracking-widest uppercase gap-1.5">
                            <span className="p-1 px-2.5 bg-red-600 rounded">OUT OF STOCK</span>
                            <span className="text-[9px] text-slate-300 lowercase font-sans">restock batch pending</span>
                          </div>
                        )}

                        <ProductImage
                          productId={product.id}
                          productName={product.name}
                          imageUrl={product.image}
                          loading="lazy"
                          className="w-full h-full relative overflow-hidden"
                          imgClassName="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                        />

                        {/* Left category badge */}
                        <div className="absolute top-2.5 left-2.5 bg-slate-900/70 backdrop-blur-md text-white text-[9px] font-bold uppercase tracking-widest font-mono px-2 py-0.5 rounded-full border border-white/15">
                          {product.cat}
                        </div>

                        {/* Right Wishlist button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleWishlist(product.id);
                          }}
                          className="absolute top-2.5 right-2.5 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md hover:bg-white dark:hover:bg-slate-900 rounded-full p-1.5 text-slate-600 dark:text-slate-300 border border-white/30 dark:border-slate-800 transition shadow-sm"
                          title="Add to biological wishlist"
                          id={`wishlist-toggle-${product.id}`}
                        >
                          <Heart className={`w-4 h-4 transition ${isInWishlist ? 'text-rose-500 fill-rose-500' : ''}`} />
                        </button>

                      </div>

                      {/* Card Info Box */}
                      <div className="p-3.5 flex-1 flex flex-col justify-between">
                        <div>
                          {/* Name and dose unit */}
                          <div className="flex items-start justify-between gap-1.5">
                            <h4 className="font-display font-extrabold text-xs sm:text-[13px] md:text-sm text-slate-800 dark:text-slate-50 leading-snug tracking-tight">
                              {product.name}
                            </h4>
                            <span className="bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400 font-mono text-[9px] font-bold px-1.5 py-0.2 rounded border border-teal-200/40 dark:border-teal-900/40 shrink-0">
                              {product.unit}
                            </span>
                          </div>

                          {/* Brief scientific abstract */}
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                            {product.desc}
                          </p>
                        </div>

                        {/* Price and Add button bar */}
                        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2">
                          <div className="flex flex-col">
                            <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 uppercase tracking-wider">cost / dosage</span>
                            <span className="font-display font-black text-xs sm:text-[15px] text-teal-600 dark:text-teal-400">
                              ₱{product.price.toLocaleString()}
                            </span>
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAddToCart(product, 1);
                            }}
                            disabled={outOfStock}
                            className={`px-3 py-1.5 rounded-full text-[11px] font-bold tracking-wide uppercase transition-all flex items-center gap-1.5 cursor-pointer ${
                              outOfStock
                                ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-200 dark:border-slate-800'
                                : 'bg-teal-600 hover:bg-teal-700 text-white shadow-md shadow-teal-600/10 hover:shadow-teal-600/20'
                            }`}
                            id={`add-to-cart-btn-${product.id}`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </button>
                        </div>

                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* Recently Viewed Block */}
        {recentViewed.length > 0 && (
          <div className="mt-14 pt-8 border-t border-slate-200 dark:border-slate-800">
            <h3 className="font-display font-extrabold text-base sm:text-lg flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5 text-teal-500" />
              <span>Recently Consulted Formulations</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3.5">
              {recentViewed
                .map(id => productsList.find(x => x.id === id))
                .filter((p): p is Product => !!p)
                .map(p => (
                  <div
                    key={p.id}
                    onClick={() => handleOpenProduct(p)}
                    className="bg-white dark:bg-slate-800 rounded-xl p-2.5 border border-slate-200/60 dark:border-slate-800 hover-lift cursor-pointer shadow-xs flex items-center gap-3 transition"
                    id={`recent-item-${p.id}`}
                  >
                    <ProductImage
                      productId={p.id}
                      productName={p.name}
                      imageUrl={p.image}
                      className="w-10 h-10 rounded-lg flex-shrink-0 relative overflow-hidden"
                      imgClassName="w-full h-full object-cover bg-slate-50"
                    />

                    <div className="overflow-hidden">
                      <h4 className="font-bold text-xs truncate text-slate-800 dark:text-slate-100">
                        {p.name}
                      </h4>
                      <p className="text-[10px] text-teal-600 dark:text-teal-400 font-mono font-bold mt-0.5">
                        ₱{p.price.toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

      </section>

      {/* FOOTER SECTION */}
      <footer className="bg-slate-900 border-t border-slate-950 text-slate-400 py-12 px-4 transition-colors">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Col 1: Bio Branding */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white">
                <FlaskConical className="w-4 h-4" />
              </div>
              <span className="font-display font-black text-lg text-white">Dose of Forever</span>
            </div>
            
            <p className="text-xs leading-relaxed text-slate-500">
              Philippines top chemical research vials supply center. Formulated to state-of-the-art standards for high reproducibility in physical, longevity, and metabolic assays inside recognized research institution platforms.
            </p>
            
            <div className="text-[10px] font-mono text-amber-500 bg-amber-500/10 p-2.5 rounded-lg border border-amber-500/20 leading-normal inline-block">
              ⚠️ STATED DEFINITION: All reagents are strictly designated for clinical assay, in-vitro research, and in-vitro laboratory studies. Not prepared for diagnostic nor internal veterinary applications.
            </div>
          </div>

          {/* Col 2: High Purity Guidelines */}
          <div className="space-y-3 text-xs">
            <h4 className="text-white font-extrabold font-mono uppercase tracking-wider text-xs">
              RESEARCH QUALITY METRICS
            </h4>
            
            <ul className="space-y-2 font-mono">
              <li>• Chemical Purity: &gt;99% Analytical (HPLC Checked)</li>
              <li>• Vial Fill Margin: Guaranteed lyophilized structure</li>
              <li>• Delivery Packing: Sealed insulated container standard</li>
              <li>• Region Partner: Lalamove Urgent Courier Service</li>
              <li>• Response Rate: Under 15-min Average WhatsApp team feedback</li>
            </ul>
          </div>

          {/* Col 3: Contacts */}
          <div className="space-y-3 text-xs">
            <h4 className="text-white font-extrabold font-mono uppercase tracking-wider text-xs">
              MESSAGING & LABORATORY LOGISTICS
            </h4>

            <p className="leading-relaxed text-slate-500">
              For bulk custom research assays, formulation requests, or detailed certificates of chemical analysis (COA) requests, dispatch direct inquiries below.
            </p>

            <a
              href="https://wa.me/639310103077"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-full transition"
              id="whatsapp-chat-footer"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Inquire over WhatsApp</span>
            </a>
          </div>

        </div>

        {/* Bottom Rights */}
        <div className="max-w-6xl mx-auto border-t border-slate-800/60 mt-10 pt-6 flex flex-col sm:flex-row justify-between text-[11px] text-slate-600 font-mono gap-4">
          <span>
            © {new Date().getFullYear()} DOSE OF FOREVER RESEARCH SUPPLIES INC. ALL COAS RESERVED.
          </span>
          <div className="flex gap-4 flex-wrap">
            <span className="hover:text-slate-500 cursor-pointer">Protocol Guidelines</span>
            <span className="hover:text-slate-500 cursor-pointer">Reconstitution Guide</span>
            <span className="hover:text-slate-500 cursor-pointer">Liability Statement</span>
            <button
              onClick={() => {
                if (user && user.email === 'pankaj.ydv707@gmail.com') {
                  setIsAdminDashboardOpen(true);
                } else {
                  handleGoogleSignIn().then(() => {
                    const freshUser = auth.currentUser;
                    if (freshUser && freshUser.email === 'pankaj.ydv707@gmail.com') {
                      setIsAdminDashboardOpen(true);
                    } else if (freshUser) {
                      showToast(`Verification blocked. Email ${freshUser.email} is unauthorized.`, 'warn');
                    }
                  });
                }
              }}
              className="text-slate-600 hover:text-amber-500 hover:underline cursor-pointer text-left font-sans font-semibold text-[11px] transition-colors"
              id="footer-admin-login-btn"
            >
              🔒 Admin Access
            </button>
          </div>
        </div>
      </footer>

      {/* --- DYNAMIC PRODUCT DRAWER / DETAIL DIALOG --- */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
            
            {/* Click outer to close */}
            <div className="absolute inset-0" onClick={() => setSelectedProduct(null)}></div>
            
            <motion.div
              initial={{ y: 200, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 200, opacity: 0 }}
              className="bg-white dark:bg-slate-800 w-full sm:max-w-3xl rounded-t-3xl sm:rounded-3xl max-h-[92vh] sm:max-h-[85vh] overflow-y-auto relative shadow-2xl border border-slate-200/50 dark:border-slate-700 z-10 flex flex-col md:flex-row"
              id="product-detail-drawer"
            >
              {/* Close Button top-right */}
              <button
                onClick={() => setSelectedProduct(null)}
                className="absolute top-4 right-4 z-20 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 p-2 rounded-full text-slate-500 dark:text-slate-300 transition"
                title="Close drawer"
                id="close-product-detail-btn"
              >
                <X className="w-5 h-5" />
              </button>

              {/* MD Column Left: Visual Represent */}
              <div className="w-full md:w-1/2 aspect-square md:aspect-auto md:h-stretch bg-slate-100 dark:bg-slate-900 relative">
                <ProductImage
                  productId={selectedProduct.id}
                  productName={selectedProduct.name}
                  imageUrl={selectedProduct.image}
                  className="w-full h-full relative overflow-hidden"
                  imgClassName="w-full h-full object-cover"
                />
                
                {/* Category tag */}
                <span className="absolute bottom-4 left-4 bg-slate-900/65 backdrop-blur-md text-white text-xs font-bold uppercase tracking-widest font-mono px-3 py-1 rounded-full border border-white/10">
                  {selectedProduct.cat}
                </span>
              </div>

              {/* MD Column Right: Info and State controls */}
              <div className="p-6 md:p-8 w-full md:w-1/2 space-y-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-[10px] bg-teal-500/10 text-teal-600 dark:text-teal-400 font-mono font-bold px-2 py-0.5 rounded border border-teal-500/20">
                      STRUCTURAL VIAL COA CHECKED
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      Popularity Score: {selectedProduct.popularity}/100
                    </span>
                  </div>

                  <h3 className="font-display font-black text-2xl text-slate-800 dark:text-slate-100 mt-2">
                    {selectedProduct.name}
                  </h3>

                  {/* Pricing tag */}
                  <div className="flex items-baseline gap-3 mt-3">
                    <span className="font-display font-black text-3xl text-teal-600 dark:text-teal-400">
                      ₱{selectedProduct.price.toLocaleString()}
                    </span>
                    <span className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs px-2 py-0.5 rounded font-mono font-bold">
                      {selectedProduct.unit} Vials
                    </span>
                  </div>

                  {/* Bio Stock Level Indicator */}
                  <div className="mt-2.5">
                    {selectedProduct.stock === 0 ? (
                      <span className="inline-flex items-center gap-1.5 text-xs text-rose-500 font-bold bg-rose-500/10 px-3 py-1 rounded-full border border-rose-500/20">
                        ● Out of stock - Next LC-MS batch crystallization pending
                      </span>
                    ) : selectedProduct.stock <= 3 ? (
                      <span className="inline-flex items-center gap-1.5 text-xs text-amber-500 font-bold bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
                        ⚠️ High demand reservation list restricted to {selectedProduct.stock} left
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-medium bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                        ✓ Assay supply active in stock ({selectedProduct.stock} units)
                      </span>
                    )}
                  </div>

                  {/* Formula Description */}
                  <div className="mt-5 space-y-2">
                    <h5 className="font-mono text-xs font-bold text-slate-400 uppercase tracking-wider">
                      REAGENT MONOGRAPH ABSTRACT
                    </h5>
                    
                    <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                      {selectedProduct.desc}
                    </p>

                    <p className="text-[11px] text-slate-400 dark:text-slate-500 italic mt-1 leading-normal">
                      *Note: Lyophilized powder structure requires proper reconstitution using bacteriostatic agents (BacWater PH) under sterile biosafety protocols.
                    </p>
                  </div>

                  {/* Config-based e-commerce product package add-on options */}
                  <ProductAddonsSelector
                    basePrice={selectedProduct.price}
                    selectedAddonId={selectedAddonId}
                    onChange={(id) => setSelectedAddonId(id)}
                  />

                  {/* Quantity selector */}
                  {selectedProduct.stock > 0 && (
                    <div className="mt-6 flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
                        select quantity:
                      </span>
                      
                      <div className="flex items-center bg-slate-100 dark:bg-slate-900 rounded-full border border-slate-200 dark:border-slate-850 p-1">
                        <button
                          onClick={() => setDrawerQty(prev => Math.max(1, prev - 1))}
                          className="w-8 h-8 rounded-full hover:bg-white dark:hover:bg-slate-800 flex items-center justify-center transition"
                          title="Reduce"
                        >
                          <Minus className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                        </button>
                        
                        <span className="w-12 text-center text-sm font-bold font-mono">
                          {drawerQty}
                        </span>
                        
                        <button
                          onClick={() => setDrawerQty(prev => Math.min(selectedProduct.stock, prev + 1))}
                          className="w-8 h-8 rounded-full hover:bg-white dark:hover:bg-slate-800 flex items-center justify-center transition"
                          title="Increase"
                        >
                          <Plus className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Realistic peer review references */}
                  <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800/80">
                    <h6 className="font-mono text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-2.5">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" /> REVOLVING ANALYSIS ASSESSMENTS
                    </h6>
                    
                    <div className="space-y-3.5">
                      {getProductReviews(selectedProduct).map((r, ri) => (
                        <div key={ri} className="bg-slate-50 dark:bg-slate-900/30 p-2.5 rounded-xl text-xs space-y-1">
                          <div className="flex items-center justify-between font-bold">
                            <span className="text-slate-700 dark:text-slate-200">{r.user}</span>
                            <span className="text-amber-500 font-sans flex items-center">⭐ {r.rating}/5</span>
                          </div>
                          <p className="text-slate-500 dark:text-slate-400 leading-relaxed italic">
                            &quot;{r.comment}&quot;
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

                <div className="space-y-2 mt-6">
                  {/* Cart Action button */}
                  <button
                    onClick={() => {
                      handleAddToCart(selectedProduct, drawerQty, selectedAddonId);
                      setSelectedProduct(null);
                    }}
                    disabled={selectedProduct.stock === 0}
                    className={`w-full font-bold py-3.5 rounded-full text-center flex items-center justify-center gap-2 transition text-sm cursor-pointer ${
                      selectedProduct.stock === 0
                        ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                        : 'bg-teal-600 hover:bg-teal-700 text-white shadow-xl shadow-teal-600/10'
                    }`}
                    id="add-to-cart-drawer-btn"
                  >
                    <ShoppingCart className="w-4.5 h-4.5" />
                    <span>
                      {selectedProduct.stock === 0 
                        ? 'Currently Out of Supply' 
                        : (() => {
                            const activeAddon = ADDON_OPTIONS.find(opt => opt.id === selectedAddonId) || ADDON_OPTIONS[0];
                            const calculatedTotal = (selectedProduct.price + activeAddon.priceModifier) * drawerQty;
                            return `Add to Research Cart — ₱${calculatedTotal.toLocaleString()}`;
                          })()
                      }
                    </span>
                  </button>

                  {/* Wishlist Toggle button */}
                  <button
                    onClick={() => handleToggleWishlist(selectedProduct.id)}
                    className="w-full border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50 text-slate-700 dark:text-slate-300 font-bold py-2.5 rounded-full text-center text-xs transition cursor-pointer"
                    id="wishlist-toggle-drawer-btn"
                  >
                    {wishlist.includes(selectedProduct.id) ? '♥ Remove from Wishlist' : '♡ Add to Biological Wishlist'}
                  </button>
                </div>

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- SIDEBAR WISHLIST DRAWER PANEL --- */}
      <AnimatePresence>
        {isWishlistOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex justify-end">
            
            {/* Click outer to close */}
            <div className="absolute inset-0" onClick={() => setIsWishlistOpen(false)}></div>
            
            <motion.div
              initial={{ x: 400, opacity: 0.9 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 400, opacity: 0.9 }}
              className="bg-white dark:bg-slate-800 w-full max-w-sm h-full shadow-2xl relative z-10 flex flex-col justify-between border-l border-slate-200 dark:border-slate-700"
              id="wishlist-drawer"
            >
              <div>
                
                {/* Drawer top bar padding */}
                <div className="p-4 bg-gradient-to-r from-teal-600 to-teal-500 text-white flex items-center justify-between">
                  <h3 className="font-display font-extrabold text-lg flex items-center gap-2">
                    <Heart className="w-5 h-5 fill-white" />
                    <span>Biological Wishlist</span>
                  </h3>
                  
                  <button
                    onClick={() => setIsWishlistOpen(false)}
                    className="text-white bg-white/10 hover:bg-white/20 p-1.5 rounded-full transition"
                    title="Close"
                    id="close-wishlist-drawer-btn"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Items wrapper */}
                <div className="p-4 space-y-3.5 max-h-[75vh] overflow-y-auto">
                  {wishlist.length === 0 ? (
                    <div className="text-center py-20 text-slate-400 space-y-2">
                      <Heart className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-sm font-semibold">Your analytical wishlist is empty</p>
                      <p className="text-xs">Explore and tag chemical structures to preserve catalog references.</p>
                    </div>
                  ) : (
                    wishlist.map(id => {
                      const item = productsList.find(x => x.id === id);
                      if (!item) return null;
                      return (
                        <div
                          key={item.id}
                          onClick={() => {
                            setSelectedProduct(item);
                            setIsWishlistOpen(false);
                          }}
                          className="flex gap-3 bg-slate-50 dark:bg-slate-900/60 p-3 rounded-2xl cursor-pointer border border-slate-200/40 dark:border-slate-800 hover:border-teal-500/40 transition"
                          id={`wishlist-item-${item.id}`}
                        >
                          <ProductImage
                            productId={item.id}
                            productName={item.name}
                            imageUrl={item.image}
                            className="w-12 h-12 rounded-xl flex-shrink-0 relative overflow-hidden"
                            imgClassName="w-full h-full object-cover bg-slate-100"
                          />
                          
                          <div className="flex-1 overflow-hidden">
                            <div className="flex justify-between items-start gap-1">
                              <h4 className="font-bold text-xs truncate text-slate-800 dark:text-slate-100">
                                {item.name}
                              </h4>
                              <span className="text-[9px] bg-slate-200 dark:bg-slate-700 rounded px-1 text-slate-500 dark:text-slate-400 font-mono">
                                {item.unit}
                              </span>
                            </div>
                            
                            <p className="font-mono text-xs font-bold text-teal-600 dark:text-teal-400 mt-1">
                              ₱{item.price.toLocaleString()}
                            </p>
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleWishlist(item.id);
                            }}
                            className="text-xs text-rose-500 hover:underline p-1 self-center"
                            title="Remove target"
                            id={`remove-wishlist-item-${item.id}`}
                          >
                            Remove
                          </button>
                        </div>
                      );
                    })
                  )}
                </div>

              </div>

              {/* Close triggers wrapper */}
              <div className="p-4 bg-slate-50 dark:bg-slate-900 border-t border-slate-200/50 dark:border-slate-700">
                <button
                  onClick={() => setIsWishlistOpen(false)}
                  className="w-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-white font-bold py-2.5 rounded-full hover:bg-slate-300 dark:hover:bg-slate-600 transition text-xs cursor-pointer"
                  id="close-wishlist-and-explore-btn"
                >
                  Return to Formulation Catalog
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- SIDEBAR ACTIVE CART DRAWER PANEL --- */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex justify-end">
            
            <div className="absolute inset-0" onClick={() => setIsCartOpen(false)}></div>
            
            <motion.div
              initial={{ x: 400, opacity: 0.9 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 400, opacity: 0.9 }}
              className="bg-white dark:bg-slate-800 w-full max-w-md h-full shadow-2xl relative z-10 flex flex-col justify-between border-l border-slate-200 dark:border-slate-700"
              id="cart-drawer"
            >
              {/* Drawer Top Header */}
              <div>
                <div className="p-4 bg-gradient-to-r from-teal-700 to-teal-600 text-white flex items-center justify-between shadow">
                  <div>
                    <h3 className="font-display font-extrabold text-lg flex items-center gap-2">
                      <ShoppingCart className="w-5 h-5 text-teal-300" />
                      <span>Research Assay Cart</span>
                    </h3>
                    <p className="text-[10px] text-teal-100/80 font-mono tracking-wider mt-0.5">
                      AUTHORIZED DIRECT PROCUREMENT
                    </p>
                  </div>
                  
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="text-white bg-white/10 hover:bg-white/20 p-1.5 rounded-full transition"
                    title="Close research cart"
                    id="close-cart-drawer-btn"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Free Delivery alert progress strip */}
                <div className="bg-amber-500/10 border-b border-amber-500/20 p-3 flex justify-between items-center text-xs text-amber-800 dark:text-amber-400 gap-3">
                  <div className="flex gap-1.5 items-center">
                    <Gift className="w-4 h-4 text-amber-500 flex-shrink-0" />
                    <span>
                      {isFreeShipping 
                        ? '🎉 Insured refrigeration courier unlocked!' 
                        : `Add ₱${remainingForFreeShipping.toLocaleString()} to qualify for free courier`
                      }
                    </span>
                  </div>
                  <strong className="font-mono text-[10px] bg-amber-500/10 border border-amber-500/20 rounded px-1.5 py-0.2 shrink-0">
                    5K PHP
                  </strong>
                </div>

                {/* Cart Active Items Loop */}
                <div className="p-4 space-y-3 max-h-[60vh] overflow-y-auto">
                  {cart.length === 0 ? (
                    <div className="text-center py-20 text-slate-400 space-y-3">
                      <ShoppingCart className="w-12 h-12 text-slate-300 mx-auto" />
                      <p className="text-sm font-semibold">Your research cart is empty</p>
                      <p className="text-xs">Select and add certified high-purity vial standards to perform your planned assays.</p>
                      <button
                        onClick={() => setIsCartOpen(false)}
                        className="mt-3 text-xs bg-teal-600 text-white px-4 py-2 rounded-full font-bold shadow-sm"
                        id="empty-cart-return-explore-btn"
                      >
                        Explore Assays
                      </button>
                    </div>
                  ) : (
                    <AnimatePresence initial={false}>
                      {cart.map(item => (
                        <CartItemCard
                          key={item.id}
                          item={item}
                          handleRemoveCartItem={handleRemoveCartItem}
                          handleCartQtyChange={handleCartQtyChange}
                        />
                      ))}
                    </AnimatePresence>
                  )}
                </div>

              </div>

              {/* Drawer Bottom controls Checkout */}
              {cart.length > 0 && (
                <div className="p-4 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 space-y-4">
                  
                  {/* Totals Box */}
                  <div className="space-y-2 text-xs font-mono">
                    <div className="flex justify-between text-slate-500">
                      <span>Assayed Reagents Total:</span>
                      <strong className="text-slate-800 dark:text-white">₱{subtotal.toLocaleString()}</strong>
                    </div>

                    <div className="flex justify-between text-slate-500">
                      <span>Insured Cold Dispatch Fee:</span>
                      {isFreeShipping ? (
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold">₱0 (PROMO FREE)</span>
                      ) : (
                        <strong className="text-slate-800 dark:text-white">₱150 (Lalamove standard)</strong>
                      )}
                    </div>

                    <div className="flex justify-between text-sm border-t border-slate-200 dark:border-slate-800 pt-2 font-display font-black">
                      <span className="text-slate-700 dark:text-slate-200">TOTAL DUE ESTIMATE:</span>
                      <span className="text-teal-600 dark:text-teal-400 text-lg">
                        ₱{totalAmountDue.toLocaleString()} PHP
                      </span>
                    </div>
                  </div>

                  {/* Actions Grid */}
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="w-full border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold py-3.5 rounded-full text-xs text-center transition hover:bg-slate-100 dark:hover:bg-slate-850 cursor-pointer"
                      id="cart-continue-buying-btn"
                    >
                      Continue Shopping
                    </button>

                    <button
                      onClick={() => {
                        setIsCartOpen(false);
                        setCheckoutStep(1);
                        setIsCheckoutOpen(true);
                      }}
                      className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-3.5 rounded-full text-xs text-center transition shadow-lg shadow-teal-500/10 cursor-pointer"
                      id="cart-proceed-checkout-btn"
                    >
                      Buy
                    </button>
                  </div>

                  <p className="text-[10px] text-center text-slate-400 italic">
                    *Reservations are locked for 24-hours pending payment confirmation.
                  </p>
                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- DYNAMIC RESEARCH ANALYTICAL QUEST / QUIZ MODAL --- */}
      <AnimatePresence>
        {isQuizOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
            
            <div className="absolute inset-0" onClick={() => setIsQuizOpen(false)}></div>
            
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-810 rounded-3xl p-6 md:p-8 max-w-md w-full relative z-10 shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col justify-between"
              id="recommender-quiz-modal"
            >
              {/* Header Title */}
              <div>
                <div className="flex items-center justify-between border-b border-slate-200/60 dark:border-slate-800 pb-3">
                  <h4 className="font-display font-extrabold text-lg text-teal-600 dark:text-teal-400 flex items-center gap-2">
                    <FlaskConical className="w-5 h-5" /> Recommended Assay Reagents
                  </h4>
                  <button
                    onClick={() => setIsQuizOpen(false)}
                    className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-full"
                    title="Close quiz"
                    id="close-quiz-btn"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mt-3 uppercase tracking-widest font-bold">
                  <span>Pathway recommendation Wizard</span>
                  <span>Step {quizStep} of 3</span>
                </div>

                {/* Progress bar indicators */}
                <div className="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full mt-2 flex gap-1 Overflow-hidden">
                  <div className={`h-full rounded-full transition-all duration-300 ${quizStep >= 1 ? 'bg-teal-600 flex-1' : 'bg-transparent'}`}></div>
                  <div className={`h-full rounded-full transition-all duration-300 ${quizStep >= 2 ? 'bg-teal-600 flex-1' : 'bg-transparent'}`}></div>
                  <div className={`h-full rounded-full transition-all duration-300 ${quizStep >= 3 ? 'bg-teal-600 flex-1' : 'bg-transparent'}`}></div>
                </div>

                {/* STEPS CONTAINER */}
                <div className="mt-6">
                  
                  {quizStep === 1 && (
                    <div className="space-y-4">
                      <div>
                        <h5 className="font-display font-bold text-slate-800 dark:text-slate-100 text-sm sm:text-base leading-snug">
                          Q1: What is the primary investigative goal of your current validation research?
                        </h5>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                          Our formulas are calibrated to optimize distinct biological pathways.
                        </p>
                      </div>

                      <div className="grid gap-2.5">
                        {[
                          { key: 'healing', label: 'Cellular recovery, tissue repair, gut barrier pathways', icon: <Activity className="w-4 h-4 text-teal-500" /> },
                          { key: 'weight', label: 'Lipolytic optimization, satiety & GLP-1/GIP receptor pathways', icon: <Scale className="w-4 h-4 text-emerald-500" /> },
                          { key: 'brain', label: 'Neurogenesis, sirtuin cofactor pathways, Pineal longevity assays', icon: <Brain className="w-4 h-4 text-indigo-500" /> },
                          { key: 'standards', label: 'Bacteriostatic solutions, reconstitution solvents', icon: <Beaker className="w-4 h-4 text-amber-500" /> }
                        ].map(opt => {
                          const isSel = quizSelectedGoal === opt.key;
                          return (
                            <button
                              key={opt.key}
                              onClick={() => setQuizSelectedGoal(opt.key)}
                              className={`p-3.5 rounded-2xl text-left border flex items-center gap-3.5 transition cursor-pointer text-xs sm:text-sm font-semibold leading-normal ${
                                isSel
                                  ? 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border-teal-500'
                                  : 'bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/60 border-slate-200 dark:border-slate-800'
                              }`}
                            >
                              <div className="p-1 rounded-lg bg-slate-100 dark:bg-slate-900 flex-shrink-0">
                                {opt.icon}
                              </div>
                              <span>{opt.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {quizStep === 2 && (
                    <div className="space-y-4">
                      <div>
                        <h5 className="font-display font-bold text-slate-800 dark:text-slate-100 text-sm sm:text-base leading-snug">
                          Q2: Select the structural budget preference of your cohort research group?
                        </h5>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                          Budget parameters can scope corresponding peptide formulation concentrations.
                        </p>
                      </div>

                      <div className="grid gap-2.5">
                        {[
                          { key: 'high', label: 'High Concentration Samples (Advanced Assay Trials)', icon: <Zap className="w-4 h-4 text-amber-500" /> },
                          { key: 'standard', label: 'Standard Calibrated Portions (Aqueous Titration Level)', icon: <Target className="w-4 h-4 text-teal-500" /> }
                        ].map(opt2 => {
                          const isSel2 = quizSelectedPurity === opt2.key;
                          return (
                            <button
                              key={opt2.key}
                              onClick={() => setQuizSelectedPurity(opt2.key)}
                              className={`p-4 rounded-xl text-left border flex items-center gap-3.5 transition cursor-pointer text-xs sm:text-sm font-semibold leading-normal ${
                                isSel2
                                  ? 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border-teal-500'
                                  : 'bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/60 border-slate-200 dark:border-slate-800'
                              }`}
                            >
                              <div className="p-1 rounded-lg bg-slate-100 dark:bg-slate-900 flex-shrink-0">
                                {opt2.icon}
                              </div>
                              <span>{opt2.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {quizStep === 3 && (
                    <div className="space-y-4">
                      <div>
                        <h5 className="font-display font-bold text-slate-800 dark:text-slate-100 text-base leading-tight">
                          We found matching molecular structures!
                        </h5>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                          Based on your biochemical goals, we suggest adding these calibrated reference models:
                        </p>
                      </div>

                      <div className="space-y-3.5">
                        {quizRecommendedProducts.length === 0 ? (
                          <p className="text-xs text-slate-400 italic py-8 text-center bg-slate-50 dark:bg-slate-900/40 rounded-xl">
                            No molecular matches. Please reset and check other pathway specifications.
                          </p>
                        ) : (
                          quizRecommendedProducts.map(p => (
                            <div key={p.id} className="bg-slate-50 dark:bg-slate-900/60 p-3 rounded-2xl flex items-center gap-3 border border-slate-200/35 dark:border-slate-800">
                              <ProductImage
                                productId={p.id}
                                productName={p.name}
                                imageUrl={p.image}
                                className="w-11 h-11 rounded-lg flex-shrink-0 relative overflow-hidden"
                                imgClassName="w-full h-full object-cover bg-slate-100"
                              />
                              <div className="flex-1 overflow-hidden">
                                <h6 className="font-bold text-xs text-slate-800 dark:text-slate-100 truncate pr-2">
                                  {p.name} ({p.unit})
                                </h6>
                                <p className="font-mono text-xs text-teal-600 dark:text-teal-400 mt-0.5">
                                  ₱{p.price.toLocaleString()}
                                </p>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}

                </div>
              </div>

              {/* Quiz Footer controls */}
              <div className="mt-8 pt-4 border-t border-slate-200/60 dark:border-slate-800 flex justify-between gap-3 font-semibold text-xs shrink-0">
                
                {/* Back button */}
                <button
                  onClick={() => setQuizStep(prev => Math.max(1, prev - 1))}
                  className={`px-4 py-2.5 rounded-full border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer ${
                    quizStep === 1 ? 'invisible' : 'visible'
                  }`}
                  id="quiz-back-btn"
                >
                  Back Step
                </button>

                {quizStep < 3 ? (
                  <button
                    onClick={handleQuizNext}
                    className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-full transition cursor-pointer"
                    id="quiz-next-btn"
                  >
                    Next Question
                  </button>
                ) : (
                  <div className="flex gap-2">
                    <button
                      onClick={() => setIsQuizOpen(false)}
                      className="px-4 py-2.5 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded-full cursor-pointer hover:bg-slate-100"
                      id="quiz-close-btn"
                    >
                      Dismiss
                    </button>
                    
                    <button
                      onClick={handleAddQuizProductsToCart}
                      disabled={quizRecommendedProducts.length === 0}
                      className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-900 rounded-full font-bold transition shadow shadow-amber-500/10 cursor-pointer disabled:opacity-50"
                      id="quiz-add-all-btn"
                    >
                      Add Recommendations
                    </button>
                  </div>
                )}

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- CHECKOUT WIZARD MODAL POPUP --- */}
      <AnimatePresence>
        {isCheckoutOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            
            <div className="absolute inset-0" onClick={() => setIsCheckoutOpen(false)}></div>
            
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[92vh] sm:max-h-[85vh] shadow-2xl relative border border-slate-200/55 dark:border-slate-700 overflow-hidden flex flex-col z-10"
              id="checkout-wizard-modal"
            >
              {/* Top Header checkout */}
              <div className="p-5 bg-gradient-to-r from-teal-700 to-teal-600 text-white flex items-center justify-between">
                <div>
                  <h4 className="font-display font-extrabold text-lg flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-teal-300" /> Secure Reserve Request
                  </h4>
                  <p className="text-[10px] text-teal-100/80 font-mono tracking-wider mt-0.5">
                    STEP {checkoutStep} OF 3 - LABORATORY COMPLIANCE DOCUMENTATION
                  </p>
                </div>

                <button
                  onClick={() => setIsCheckoutOpen(false)}
                  className="text-white bg-white/10 hover:bg-white/20 p-1.5 rounded-full transition"
                  title="Close checkout"
                  id="close-checkout-dismiss-btn"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Progress Bar steps */}
              <div className="px-5 pt-4 flex gap-2 justify-center">
                {['Researcher Details', 'Refrigerated Cold Dispatch', 'Receipt Proof-of-Pay'].map((label, idx) => {
                  const stepNum = idx + 1;
                  const isActive = checkoutStep === stepNum;
                  const isDone = checkoutStep > stepNum;
                  return (
                    <div key={label} className="flex-1 flex flex-col items-center gap-1.5 text-center">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold font-mono transition-colors ${
                        isActive 
                          ? 'bg-teal-600 text-white' 
                          : isDone 
                          ? 'bg-emerald-500 text-white' 
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-400'
                      }`}>
                        {isDone ? '✓' : stepNum}
                      </div>
                      <span className={`text-[10px] font-mono leading-none tracking-tight hidden sm:block ${isActive ? 'text-teal-600 dark:text-teal-400 font-bold' : 'text-slate-400'}`}>
                        {label}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Wizard Content Body Form */}
              <form onSubmit={handleCheckoutNextStep} className="p-5 flex-1 overflow-y-auto space-y-4">
                
                {checkoutStep === 1 && (
                  <div className="space-y-3.5">
                    <div className="flex items-center gap-2 p-3 bg-slate-500/5 rounded-xl text-slate-600 dark:text-slate-400 text-xs border border-slate-500/10">
                      <User className="w-4.5 h-4.5 text-slate-500 flex-shrink-0" />
                      <p>
                        Provide accurate researcher contact information. All dispatch confirmations are coordinated via WhatsApp Messenger.
                      </p>
                    </div>

                    {!user ? (
                      <div className="p-3.5 rounded-xl border border-dashed border-teal-500/25 bg-teal-500/5 dark:bg-teal-950/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                        <div className="space-y-0.5">
                          <p className="font-semibold text-teal-700 dark:text-teal-400">Expedite Dispatch Integration</p>
                          <p className="text-slate-500 dark:text-slate-400 text-[11px]">Sign in with Google to auto-fill research credentials.</p>
                        </div>
                        <button
                          type="button"
                          onClick={handleGoogleSignIn}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-medium text-xs transition shadow-sm cursor-pointer self-stretch sm:self-auto text-center justify-center font-mono"
                          id="checkout-google-signin-btn"
                        >
                          <LogIn className="w-3.5 h-3.5" />
                          <span>GOOGLE SIGN-IN</span>
                        </button>
                      </div>
                     ) : (
                      <div className="flex flex-col gap-2 p-3.5 rounded-xl border border-emerald-500/15 bg-emerald-500/5 text-emerald-700 dark:text-emerald-400 text-xs">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            {user.photoURL ? (
                              <img src={user.photoURL} alt="" className="w-6 h-6 rounded-full border border-emerald-500/20" referrerPolicy="no-referrer" />
                            ) : (
                              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center font-semibold text-[10px] uppercase">
                                {user.displayName?.charAt(0) || 'U'}
                              </span>
                            )}
                            <div className="truncate max-w-[170px] sm:max-w-xs">
                              <span className="font-semibold">Researcher Profile:</span> {user.displayName || user.email}
                            </div>
                          </div>
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-600 px-1.5 py-0.5 rounded font-mono font-medium flex-shrink-0">VERIFIED</span>
                        </div>
                        <div className="pt-2 border-t border-emerald-500/10 flex items-center justify-between text-[11px] font-mono">
                          <span className="text-slate-400 dark:text-slate-500">RESEARCHER ID:</span>
                          <span className="text-slate-600 dark:text-slate-300 select-all font-semibold break-all">{user.uid}</span>
                        </div>
                      </div>
                    )}

                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-1">
                          RECIPIENT RESEARCHER NAME *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="Consignee Full name (e.g., Prof./Dr. Juan dela Cruz)"
                          value={coName}
                          onChange={(e) => setCoName(e.target.value)}
                          className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm focus:ring-1 focus:ring-teal-500"
                        />
                      </div>

                      <div className="grid sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-1">
                            WHATSAPP MOBILE PHONE *
                          </label>
                          <input
                            type="tel"
                            required
                            placeholder="Mobile (e.g., 09171234567)"
                            value={coMobile}
                            onChange={(e) => setCoMobile(e.target.value)}
                            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm focus:ring-1 focus:ring-teal-500"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-1">
                            EMAIL FOR RESERVATION RECEIPT *
                          </label>
                          <input
                            type="email"
                            placeholder="Academic/Research Email (e.g., researcher@uni.edu.ph)"
                            value={coEmail}
                            onChange={(e) => setCoEmail(e.target.value)}
                            required
                            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm focus:ring-1 focus:ring-teal-500"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {checkoutStep === 2 && (
                  <div className="space-y-4">
                    <div>
                      <span className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                        SELECT METRO COURIER DISPATCH *
                      </span>

                      <div className="grid grid-cols-2 gap-3">
                        <label className={`p-4 border rounded-2xl flex flex-col justify-between cursor-pointer text-left transition select-none ${
                          coDelivery === 'lalamove'
                            ? 'bg-teal-500/5 text-teal-600 dark:text-teal-400 border-teal-500'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                        }`}>
                          <div className="flex items-center gap-2 font-bold mb-1">
                            <input
                              type="radio"
                              name="courierOption"
                              checked={coDelivery === 'lalamove'}
                              onChange={() => setCoDelivery('lalamove')}
                              className="accent-teal-600"
                            />
                            <span className="text-xs sm:text-sm">🛵 Lalamove</span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {isFreeShipping ? 'FREE PROMO' : '₱150 Standard Cold'}
                          </span>
                        </label>

                        <label className={`p-4 border rounded-2xl flex flex-col justify-between cursor-pointer text-left transition select-none ${
                          coDelivery === 'grab'
                            ? 'bg-teal-500/5 text-teal-600 dark:text-teal-400 border-teal-500'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                        }`}>
                          <div className="flex items-center gap-2 font-bold mb-1">
                            <input
                              type="radio"
                              name="courierOption"
                              checked={coDelivery === 'grab'}
                              onChange={() => setCoDelivery('grab')}
                              className="accent-teal-600"
                            />
                            <span className="text-xs sm:text-sm">🚗 Grab Car Express</span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {isFreeShipping ? 'FREE PROMO' : '₱180 Air-con'}
                          </span>
                        </label>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-1">
                        PH COMPLETE DELIVERY ADDRESS *
                      </label>
                      <textarea
                        required
                        rows={3}
                        placeholder="Provide detailed street unit address, village, or building laboratory name in the Philippines."
                        value={coAddress}
                        onChange={(e) => setCoAddress(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm focus:ring-1 focus:ring-teal-500"
                      />
                    </div>
                  </div>
                )}

                {checkoutStep === 3 && (
                  <div className="space-y-4">
                    
                    {/* Payment reference info */}
                    <div className="border border-slate-200 dark:border-slate-700 rounded-2xl p-4 space-y-3.5 bg-slate-50 dark:bg-slate-900/40 text-xs text-slate-600 dark:text-slate-300">
                      
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold text-slate-400">Total Amount Due:</span>
                        <strong className="text-teal-600 dark:text-teal-400 text-base font-display">₱{totalAmountDue.toLocaleString()} PHP</strong>
                      </div>

                      <div className="border-t border-slate-200/60 dark:border-slate-800 pt-2.5 space-y-3">
                        <p className="font-bold text-slate-700 dark:text-slate-200">
                          🏦 SECURE TRANSACTIONS VIA INSTAPAY / GCASH:
                        </p>
                        
                        <GcashQrCode />
                        
                        <div className="mt-2 text-[10.5px] text-slate-500 py-1.5 border-t border-slate-200/60 dark:border-slate-800/80">
                          Alternative Payment Gateways:
                          <ul className="mt-1 space-y-1 pl-3 font-mono list-disc text-[9.5px]">
                            <li>Maya Wallet: <span className="text-slate-700 dark:text-slate-300 font-bold">0931 010 3077</span></li>
                            <li>Banco de Oro (BDO): Direct bank transfer available over laboratory WhatsApp inquiry.</li>
                          </ul>
                        </div>
                      </div>

                    </div>

                    {/* Receipt upload interactive input */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
                        PROOF-OF-PAYMENT TRANSACTION SLIP *
                      </label>
                      
                      <input 
                        type="file"
                        ref={receiptFileInputRef}
                        onChange={handleReceiptUpload}
                        accept="image/*"
                        className="hidden"
                        id="real-receipt-file-input"
                      />

                      {coReceiptFile ? (
                        <div className="p-3 bg-teal-500/10 border border-teal-500/20 text-slate-700 dark:text-slate-300 rounded-xl text-xs space-y-2.5">
                          <div className="flex justify-between items-center">
                            <span className="font-mono text-emerald-400 font-bold flex items-center gap-1.5">
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              Uploaded: {coReceiptFile}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                setCoReceiptFile('');
                                setCoReceiptPreview('');
                                if (receiptFileInputRef.current) receiptFileInputRef.current.value = '';
                              }}
                              className="font-bold text-[10px] uppercase text-red-500 hover:text-red-400 transition-colors"
                              id="remove-receipt-ref-btn"
                            >
                              Reset Slip
                            </button>
                          </div>
                          
                          {/* Live interactive proof image visualizer */}
                          {coReceiptPreview && (
                            <div className="relative rounded-lg overflow-hidden border border-slate-700 max-h-48 flex items-center justify-center bg-slate-950/40">
                              <img 
                                src={coReceiptPreview} 
                                alt="Receipt transaction slip proof" 
                                className="max-h-48 object-contain w-auto block select-none"
                              />
                            </div>
                          )}
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={triggerRealFileSelect}
                          className="w-full flex flex-col items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-800 hover:border-teal-500/40 hover:bg-slate-900/30 p-6 rounded-2xl text-center text-xs text-slate-500 transition-colors cursor-pointer group"
                          id="mock-upload-file-btn"
                        >
                          <CreditCard className="w-8 h-8 text-slate-400 group-hover:text-teal-400 mb-2 transition-colors" />
                          <span className="font-bold text-teal-600 dark:text-teal-400 group-hover:underline">
                            Click to Browse &amp; Upload Receipt
                          </span>
                          <span className="text-[10px] text-slate-400 mt-1">Accepts any photo proof, transaction screens (limit 8MB)</span>
                        </button>
                      )}
                    </div>

                    {/* Legal Checkbox safety */}
                    <div className="pt-2">
                      <label className="inline-flex items-start gap-2.5 select-none text-xs text-slate-500 dark:text-slate-400 leading-normal cursor-pointer">
                        <input
                          type="checkbox"
                          required
                          checked={coTerms}
                          onChange={(e) => setCoTerms(e.target.checked)}
                          className="rounded border-slate-300 text-teal-600 w-4 h-4 focus:ring-teal-500 shrink-0 mt-0.5"
                        />
                        <span>
                          I acknowledge and confirm that these high-purity chemical structures are intended <strong className="text-slate-800 dark:text-slate-200">strictly for laboratory-approved research clinical trials and biochemical assays</strong>.
                        </span>
                      </label>
                    </div>

                  </div>
                )}

                {/* Submit button hidden flow control */}
                <button type="submit" className="hidden" id="submit-hidden-trigger" />
              </form>

              {/* Wizard Footer controls */}
              <div className="p-4 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 flex justify-between gap-3 font-semibold text-xs shrink-0">
                
                {/* Back button */}
                <button
                  type="button"
                  onClick={() => setCheckoutStep(prev => Math.max(1, prev - 1))}
                  className={`px-4.5 py-2.5 rounded-full border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-105 transition cursor-pointer ${
                    checkoutStep === 1 ? 'invisible' : 'visible'
                  }`}
                  id="checkout-back-step-btn"
                >
                  Back Step
                </button>

                {/* Continue button */}
                {checkoutStep < 3 ? (
                  <button
                    type="button"
                    onClick={() => {
                      // Trigger native HTML validation check on visible step inputs
                      const sib = document.getElementById('submit-hidden-trigger');
                      sib?.click();
                    }}
                    className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-full transition cursor-pointer"
                    id="checkout-continue-step-btn"
                  >
                    Next Options →
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handlePlaceOrder}
                    disabled={!coTerms || !coReceiptFile || isSendingMail}
                    className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-full font-bold transition cursor-pointer disabled:opacity-50 flex items-center gap-2"
                    id="checkout-finalize-order-btn"
                  >
                    {isSendingMail ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Transmitting Proof...</span>
                      </>
                    ) : (
                      <span>Send Reservation Proof ✓</span>
                    )}
                  </button>
                )}

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- FLOATING ACTION TRIGGER COMPACT FOR MOBILE DEVICES --- */}
      <div className="md:hidden fixed bottom-4 right-4 z-40 flex flex-col gap-2">
        
        {/* Floating WhatsApp Quick link */}
        <a
          href="https://wa.me/639310103077"
          target="_blank"
          rel="noreferrer"
          className="w-12 h-12 bg-emerald-500 text-white rounded-full flex items-center justify-center shadow-lg transition hover:scale-105"
          title="Direct WhatsApp link"
          id="whatsapp-fab-btn"
        >
          <MessageCircle className="w-5 h-5 fill-white" />
        </a>

        {/* Floating Scroll to Top button */}
        {showScrollTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="w-12 h-12 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-full flex items-center justify-center shadow-lg border border-slate-200 dark:border-slate-700 transition"
            title="Scroll back to top"
            id="scroll-top-fab-btn"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
        )}

      </div>

    </div>
  );
}
