export interface Product {
  id: number;
  name: string;
  unit: string;
  stock: number;
  price: number;
  cat: 'Peptides' | 'Weight Loss' | 'Cognitive & Sleep' | 'Lab Essentials';
  desc: string;
  image: string;
  abbr: string;
  popularity: number;
}

export interface CartItem {
  id: number;
  name: string;
  unit: string;
  price: number;
  qty: number;
  stock: number;
  image: string;
  abbr: string;
  selectedAddonId?: string;
  selectedAddonName?: string;
  selectedAddonPrice?: number;
}

export interface Review {
  user: string;
  rating: number;
  comment: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: { label: string; value: string; icon: string }[];
}
