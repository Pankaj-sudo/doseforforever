import React, { useEffect, useRef, useState } from 'react';

interface YoutubeHeroBackgroundProps {
  videoId: string;
  opacity?: number;
}

declare global {
  interface Window {
    onYouTubeIframeAPIReady?: () => void;
    YT?: any;
  }
}

export const YoutubeHeroBackground: React.FC<YoutubeHeroBackgroundProps> = ({
  videoId,
  opacity = 0.5,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const playerRef = useRef<any>(null);
  const [isReady, setIsReady] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isAudioMuted, setIsAudioMuted] = useState(true);

  useEffect(() => {
    const iframeId = `yt-bg-player-${videoId}`;
    let isMounted = true;

    // Load YT API script if not present
    if (!window.YT) {
      const existingTag = document.getElementById('youtube-sdk-script');
      if (!existingTag) {
        const tag = document.createElement('script');
        tag.id = 'youtube-sdk-script';
        tag.src = 'https://www.youtube.com/iframe_api';
        const firstScriptTag = document.getElementsByTagName('script')[0];
        if (firstScriptTag && firstScriptTag.parentNode) {
          firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
        }
      }
    }

    // Function to build player
    const initPlayer = () => {
      if (!isMounted) return;
      
      try {
        playerRef.current = new window.YT.Player(iframeId, {
          videoId: videoId,
          playerVars: {
            autoplay: 1,
            mute: 1,
            controls: 0,
            rel: 0,
            showinfo: 0,
            iv_load_policy: 3,
            modestbranding: 1,
            loop: 1,
            playlist: videoId,
            fs: 0,
            autohide: 1,
            playsinline: 1,
            disablekb: 1,
          },
          events: {
            onReady: (event: any) => {
              if (!isMounted) return;
              event.target.mute();
              event.target.playVideo();
              setIsReady(true);
            },
            onStateChange: (event: any) => {
              if (!isMounted) return;
              if (event.data === window.YT.PlayerState.PLAYING) {
                setIsPlaying(true);
              }
              // Backup looping if browser blocks standard loop parameter
              if (event.data === window.YT.PlayerState.ENDED) {
                event.target.playVideo();
              }
            },
          },
        });
      } catch (err) {
        console.error('Error initializing YouTube player:', err);
      }
    };

    // Bind API callback or initialize immediately if active
    if (window.YT && window.YT.Player) {
      initPlayer();
    } else {
      const prevCallback = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (prevCallback) prevCallback();
        initPlayer();
      };
    }

    // Interactive mouse movement forces video triggers
    const forcePlay = () => {
      if (playerRef.current && typeof playerRef.current.getPlayerState === 'function') {
        const state = playerRef.current.getPlayerState();
        if (state !== 1 && state !== 3) {
          playerRef.current.playVideo();
        }
      }
    };

    document.addEventListener('mousemove', forcePlay);
    document.addEventListener('touchstart', forcePlay);
    document.addEventListener('click', forcePlay);

    return () => {
      isMounted = false;
      document.removeEventListener('mousemove', forcePlay);
      document.removeEventListener('touchstart', forcePlay);
      document.removeEventListener('click', forcePlay);
      
      if (playerRef.current && typeof playerRef.current.destroy === 'function') {
        playerRef.current.destroy();
      }
    };
  }, [videoId]);

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!playerRef.current) return;
    
    if (isAudioMuted) {
      playerRef.current.unMute();
      setIsAudioMuted(false);
    } else {
      playerRef.current.mute();
      setIsAudioMuted(true);
    }
  };

  return (
    <div 
      ref={containerRef}
      className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none select-none z-0"
    >
      {/* YT Video Wrapper scaled to mathematical aspect ratios to cut letterboxing */}
      <div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 min-h-full min-w-full"
        style={{
          width: '100vw',
          height: '56.25vw', // 16:9
          minHeight: '100vh',
          minWidth: '177.77vh', // 16:9 Inverse
          opacity: isPlaying ? opacity : 0,
          transition: 'opacity 1.5s ease-in-out',
        }}
      >
        <div id={`yt-bg-player-${videoId}`} className="w-full h-full pointer-events-none" />
      </div>

      {/* Cinematic Linear Overlay Gradients */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-slate-950/40 z-[1] pointer-events-none" />
      <div className="absolute inset-0 bg-radial-gradient-tech opacity-[0.15] pointer-events-none z-[1]" 
           style={{
             backgroundImage: 'radial-gradient(#0d9488 1px, transparent 1px)',
             backgroundSize: '24px 24px'
           }}
      />
    </div>
  );
};
